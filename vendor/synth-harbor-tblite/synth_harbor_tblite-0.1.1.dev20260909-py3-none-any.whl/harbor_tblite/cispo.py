"""The CISPO contract this image serves, beside the Harbor surface it already has.

``harbor_tblite.targets`` is this image speaking the platform contract: a
``TargetSpec`` whose ``NestedTrialRuntime`` extracts a digest-pinned
OpenThoughts-TBLite workspace into a sibling container, runs mini-SWE against
it, grades the mutated tree in a second sibling, and reports the verifier's
``reward.txt`` as the rollout reward. That surface is unchanged and stays
exactly where it was. This module adds the newer one beside it --
``synth_optimizers.cispo.v1``: seventeen declared routes, a hashed capability
document, a clause-by-clause handshake, a session-scoped policy binding, an
asynchronous leased attempt, sealed Trace V5 evidence, and a reward receipt
bound to the digest of that evidence.

The two never collide. The canonical CISPO table names ``/taskset``,
``/rollout``, ``/reward``, ``/training/capabilities`` and the
``/rollouts/{rollout_id}/...`` family, and the shared compat platform already
serves several of those paths with blocking, GEPA-era semantics. So the
canonical shape is kept verbatim and mounted under
``synth_containers.cispo_contract.CISPO_ROUTE_PREFIX`` (``/cispo``), which the
contract explicitly allows because an executor calls only declared routes. Every
pre-existing route answers byte-for-byte what it answered before; ``/info`` gains
two additive keys (``optimizer_contracts.cispo`` and ``cispo_import_path``) and
nothing else on this image moves.

What makes this container the odd one out
-----------------------------------------

Banking77 and HealthBench finish scoring inside the episode: the classifier's
answer *is* the thing scored, and the rubric judge is a turn in the same call
stack. TBLite does not work that way. The agent and the verifier are two
different workloads in two different images -- the verifier image is built ``FROM``
the agent image with the hidden ``/tests`` layered on top, and it cannot run
until the agent has stopped writing to the workspace. So scoring genuinely does
not finish when the episode does, and this is the container that declares
:class:`~synth_containers.cispo_reward.CispoRewardAuthority` deferred scoring
and walks ``running -> awaiting_score -> completed``.

It is also the longest-horizon target here and the only one whose agent compacts
its own context, so two evidence rules that are vacuous elsewhere are live:

* **Strict prefix.** Fifty turns of one conversation, each re-rendered by the
  bound sampler. Turn *n+1*'s prompt must be a byte-for-byte extension of turn
  *n*'s prompt plus its generation, or the two calls are not one sequence.
* **Compaction provenance.** At the declared threshold the harness drops the
  middle of the transcript and replaces it with a summary. That prompt is *not*
  a prefix of the previous one, so it forks a branch, declares why, and the
  retained prefix it carries forward is loss-masked -- it is context the policy
  is conditioned on, not tokens the policy authored on this branch.

What this image declares, and why each of it is true here:

``discovery``
    The digest-pinned trials in ``pins.toml``, one task row per baked slug, over
    the splits the deployment declares. A row's content digest covers the trial
    id, the two image ids it is pinned to, the workspace path, the declared
    split, and the digest of the ``instruction.md`` the agent is actually
    handed. Change the corpus, the pin, or the instruction and the digest moves.
    Nothing about the hidden tests is in it: the verifier image is named by its
    own immutable id, and the tests inside it are never read here.

``topology``
    One trainable instance on one trainable team. A single-agent SWE episode has
    exactly one actor, so nothing here claims a roster the world does not have.

``horizon``
    ``steps``, value ``max_steps``, with a declared ``seconds_per_unit`` that is
    the container's own agent deadline divided by that step count -- so
    ``horizon_seconds()`` is exactly the ``agent_timeout_seconds`` this image
    already enforces, rather than a per-step number nobody measured. The horizon
    covers the *agent episode only*. Quiescing the workspace and running the
    verifier are post-horizon work inside the attempt's lease, declared as
    ``quiescence_budget_seconds`` and ``artifact_budget_seconds``, exactly as the
    straggler ruling asks.

``evidence``
    Captured from the agent's own sampler calls: prompt token ids, generation
    token ids and one behavior logprob per generated token, as they come back
    from whichever sampler the deployment binds. The container never tokenizes
    and never invents a logprob; a response without an aligned logprob vector is
    a refusal, because an importance ratio with no denominator is not evidence.
    Compaction forks a branch with :class:`CompactionProvenanceV1`; the sealed
    trace carries one segment per branch.

``reward``
    The verifier's number, read from the trial's declared ``reward.txt``, bound
    to the sealed trace digest and to the digest of the workspace the verifier
    graded, and delivered through the deferred path. A reward request that
    carries its own measure is refused: a measure the executor chose is not a
    container-authoritative reward.

The two things this image cannot declare on its own
---------------------------------------------------

*The tokenizer half of the renderer profile.* This container renders a
*conversation*, not tokens: the token ids it records come back from the bound
sampler. The prompt program it does own -- the mini-SWE system turn, the opening
turn template, the observation template, the compaction rule and its two
thresholds -- is pinned in ``config_digest``. The tokenizer identity and stop
token ids are deployment facts and must be supplied::

    SYNTH_TBLITE_TOKENIZER_ID=Qwen/Qwen3.5-4B
    SYNTH_TBLITE_TOKENIZER_DIGEST=sha256:<tokenizer.json digest>
    SYNTH_TBLITE_STOP_TOKEN_IDS=151645,151643

*The nested-Docker substrate.* Extracting a workspace and grading it are two
sibling ``docker run`` invocations against the host daemon. That boundary is the
:class:`TrialSubstrate` seam: :class:`HostDockerSubstrate` is the deployed one
and is what ``synth-containers up harbor-tblite`` gets; a conformance run injects
a substrate that starts no container. Without a reachable daemon and a mounted
host workspace the target is not installed and every CISPO route answers the
contract's own typed 501 (``cispo_capability_not_declared``). That is the
direction the contract asks for: a capability that cannot be declared is a
refusal, not a plausible-looking default.

Two more things are explicit rather than assumed.

*Where the contract comes from.* The CISPO stream is not in the wheel this repo
pins, so :func:`install_cispo_import_path` locates it -- ``SYNTH_CONTAINERS_CISPO_SRC``
first, then a sibling checkout -- and extends the already-imported
``synth_containers.__path__`` rather than shadowing the package on ``sys.path``.
Same variable and same mechanism as ``banking77`` and ``healthbench2``.
``CISPO_IMPORT_PATH`` records which path this process took.

*Where the advertisement goes.* Unlike ``banking77``, nothing on this image has
claimed ``metadata.optimizer_contracts.cispo``, so the seventeen-route table is
advertised under the canonical key.
"""

from __future__ import annotations

import hashlib
import importlib
import importlib.util
import json
import os
import shutil
import subprocess
import threading
import time
import urllib.error
import urllib.request
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field, replace
from datetime import datetime
from pathlib import Path
from typing import Any, Protocol
from urllib.parse import urlsplit

# --------------------------------------------------------------------------- #
# Locating the CISPO stream
# --------------------------------------------------------------------------- #

#: Environment variable naming the ``src`` directory of a synth-containers
#: checkout that carries the CISPO stream. Same name, same meaning, and the same
#: bootstrap as ``banking77`` and ``healthbench2``: one convention per fleet, or
#: a deployment has to learn a new one per image.
CISPO_SRC_ENV = "SYNTH_CONTAINERS_CISPO_SRC"

#: Checkout directory names searched when the variable is unset. These are
#: siblings of this repository on a workstation; a baked image sets the
#: variable, or ships a wheel that already carries the modules.
CISPO_SIBLING_DIRS = ("wt-containers-cispo-conformance", "containers")

#: The module whose presence proves the stream is importable.
CISPO_PROBE_MODULE = "synth_containers.cispo_contract"


class CispoSourceMissing(ImportError):
    """The CISPO stream is not importable from this checkout.

    Raised at import time of this module. ``stack.extend_app`` catches it and
    mounts nothing: a container that cannot import the stream advertises no
    CISPO route table, which is the honest answer. It never advertises routes it
    would then answer 501 on for a reason that has nothing to do with the run.
    """


def cispo_source() -> Path | None:
    """The ``src`` directory holding the CISPO stream, or ``None``.

    ``SYNTH_CONTAINERS_CISPO_SRC`` first, then a sibling checkout beside this
    repository. Mirrors ``_optimizer_src`` in the synth-containers conformance
    tests, for the same reason: one function decides, and the caller reports
    which path it took.
    """

    configured = os.environ.get(CISPO_SRC_ENV, "").strip()
    if configured:
        candidate = Path(configured)
        if (candidate / "synth_containers" / "cispo_contract.py").is_file():
            return candidate
        return None
    for parent in Path(__file__).resolve().parents:
        for name in CISPO_SIBLING_DIRS:
            candidate = parent / name / "src"
            if (candidate / "synth_containers" / "cispo_contract.py").is_file():
                return candidate
    return None


def install_cispo_import_path() -> str:
    """Make ``synth_containers.cispo_*`` importable, and say how.

    ``synth_containers`` is already imported by the time anything in this image
    runs, so putting a checkout on ``sys.path`` would do nothing: the parent
    package's ``__path__`` is what resolves its submodules. Extending that
    ``__path__`` keeps the installed package authoritative for every module it
    already has -- ``platform``, ``nested``, ``nested_runtime``, ``policies`` --
    and adds only the modules it does not, so installing the CISPO stream cannot
    change the behaviour of a route that already works.

    Returns ``"installed"`` when the stream was already importable and
    ``"path_extended:<src>"`` when this call made it importable.
    """

    if importlib.util.find_spec(CISPO_PROBE_MODULE) is not None:
        return "installed"
    source = cispo_source()
    if source is None:
        raise CispoSourceMissing(
            f"{CISPO_PROBE_MODULE} is not importable and no CISPO source was found; "
            f"set {CISPO_SRC_ENV} to the `src` directory of a synth-containers "
            "checkout that carries the cispo_* modules"
        )
    import synth_containers

    package_dir = str(source / "synth_containers")
    if package_dir not in synth_containers.__path__:
        synth_containers.__path__.append(package_dir)
    importlib.invalidate_caches()
    if importlib.util.find_spec(CISPO_PROBE_MODULE) is None:  # pragma: no cover
        raise CispoSourceMissing(
            f"extended synth_containers.__path__ with {package_dir} but "
            f"{CISPO_PROBE_MODULE} is still not importable"
        )
    return f"path_extended:{source}"


#: How this process reached the CISPO stream. Asserted in this image's tests, so
#: a run can say which build it actually served.
CISPO_IMPORT_PATH = install_cispo_import_path()


from synth_containers.capabilities import (  # noqa: E402 - after the bootstrap
    RuntimeCapabilitySurface,
    TokenEmissionCapabilities,
)
from synth_containers.cispo_contract import (  # noqa: E402
    CISPO_ROUTE_PREFIX,
    AgentInstanceDeclaration,
    CispoRuntimeDeclaration,
    DiscoveryDeclaration,
    EvidenceDeclaration,
    HorizonDeclaration,
    LeaseDeclaration,
    LifecycleDeclaration,
    PolicyBindingDeclaration,
    RecoveryDeclaration,
    RendererProfileDeclaration,
    RewardDeclaration,
    TeamDeclaration,
    TopologyDeclaration,
    build_cispo_capability_document,
    cispo_declared_routes,
    cispo_optimizer_contract,
)
from synth_containers.cispo_evidence import (  # noqa: E402
    BehaviorBindingV1,
    CispoEvidenceBuilder,
    CompactionProvenanceV1,
    EvidenceError,
    InferenceCallV1,
    RendererProfileV1,
    SamplingProfileV1,
    SealedEvidenceV1,
    assert_wire_not_flattened,
)
from synth_containers.cispo_handshake import (  # noqa: E402
    CispoHandshakeAdapter,
    RuntimeFacts,
    TaskRow,
    canonical_digest,
    task_content_digest,
)
from synth_containers.cispo_policy import (  # noqa: E402
    BoundPolicySession,
    CispoPolicyAdapter,
    ModelCallRecordV1,
    SamplerBinding,
    SamplerOriginV1,
    SamplerReachability,
    SamplerTransport,
)
from synth_containers.cispo_probe import (  # noqa: E402
    PROBE_POLICY_KIND,
    PROBE_ROLLOUT_PREFIX,
    PROBE_TOKEN_CAPTURE_PROVENANCE,
)
from synth_containers.cispo_reward import (  # noqa: E402
    CispoRewardAuthority,
    ScoringState,
)
from synth_containers.cispo_rollout import (  # noqa: E402
    AttemptRecordV1,
    CispoRolloutAdapter,
    CispoRolloutLifecycle,
)
from synth_containers.event_log import RolloutEventLog  # noqa: E402
from synth_containers.http_adapter import register_cispo_routes  # noqa: E402
from synth_containers.nested import (  # noqa: E402
    HostWorkspace,
    NestedTrial,
    nested_health,
    platform_id,
    reap_rollout,  # noqa: E402
)

# The mini-SWE harness's own rules, imported rather than restated. The prompt
# program this container pins in `config_digest` has to be the one the deployed
# policy actually runs; a second copy here would drift silently and the pinned
# digest would then describe a rendering nobody served. Three of these are
# private names in that module, which is the price of not forking the harness.
from synth_containers.policies.mini_swe import (  # noqa: E402
    FINISH_MARKER,
    SYSTEM_PROMPT,
    _command_rejection,
    _extract_command,
    _observation_text,
)
from synth_containers.tracing.canonical import utc_now  # noqa: E402

from .targets import POLICIES  # noqa: E402
from .trials import CORPUS_ROOT, pins  # noqa: E402

TARGET_SCHEMA_VERSION = "harbor_tblite.cispo.target.v1"

CONTAINER_ID = "harbor-tblite"
TASKSET_ID = "openthoughts.tblite.v1"
TASK_FAMILY = "openthoughts.tblite"
TOPOLOGY_ID = "tblite.mini_swe.solo.v1"

#: The evaluation plan this image already scores under -- the same identity the
#: platform target declares. An identity, not a dial: two reads of one episode
#: may not come from two plans.
EVALUATION_PLAN_ID = "eval:tblite.reward_txt"

#: The renderer *profile* this container owns: the mini-SWE prompt program,
#: pinned. The tokenizer half is a deployment fact -- see the module docstring.
RENDERER_PROFILE_ID = "tblite.mini_swe.prompt.v1"
TOKENIZER_ID_ENV = "SYNTH_TBLITE_TOKENIZER_ID"
TOKENIZER_DIGEST_ENV = "SYNTH_TBLITE_TOKENIZER_DIGEST"
STOP_TOKEN_IDS_ENV = "SYNTH_TBLITE_STOP_TOKEN_IDS"
IMAGE_DIGEST_ENV = "SYNTH_CONTAINER_IMAGE_DIGEST"
INSTALL_MODE_ENV = "SYNTH_TBLITE_CISPO"
HELDOUT_TASKS_ENV = "SYNTH_TBLITE_HELDOUT_TASKS"

TRAIN_SPLIT = "train"
HELDOUT_SPLIT = "heldout"

#: The policy seed this image already ships as its default. The declaration is
#: read off it rather than restated, so the horizon, the compaction thresholds
#: and the step budget cannot disagree with the harness that is actually bound.
DEFAULT_POLICY_SEED = POLICIES[0]
_AGENT_CONFIG: Mapping[str, Any] = dict(DEFAULT_POLICY_SEED.config)

MAX_STEPS = int(_AGENT_CONFIG["max_steps"])
MAX_TOKENS = int(_AGENT_CONFIG["max_tokens"])
COMMAND_TIMEOUT_SECONDS = float(_AGENT_CONFIG["command_timeout_seconds"])
AGENT_TIMEOUT_SECONDS = float(_AGENT_CONFIG["timeout_seconds"])
OUTPUT_LIMIT = int(_AGENT_CONFIG["output_limit"])
COMPACTION_THRESHOLD_TOKENS = int(_AGENT_CONFIG["compaction_threshold_tokens"])
COMPACTION_KEEP_MESSAGES = int(_AGENT_CONFIG["compaction_keep_messages"])

#: A step carries no duration of its own. This is the one the container actually
#: enforces: the agent deadline it holds the whole episode to, over the step
#: budget it holds the episode to. `horizon_seconds()` is then exactly
#: `AGENT_TIMEOUT_SECONDS` rather than a per-step guess nobody measured.
SECONDS_PER_STEP = AGENT_TIMEOUT_SECONDS / MAX_STEPS

#: The verifier's own budget. It is post-horizon work inside the attempt's lease,
#: so it is declared as the horizon's artifact-collection budget and folded into
#: the straggler deadline -- never into the horizon itself.
VERIFIER_TIMEOUT_SECONDS = 3600.0
#: Stopping whatever the agent backgrounded in the workspace.
QUIESCENCE_BUDGET_SECONDS = 60.0
#: Declared by the container, so a run configuration's grace is only a fallback.
STRAGGLER_GRACE_SECONDS = 300.0

#: A lease is a different clock from the horizon: this is how long one grant
#: survives without a heartbeat. An hour-scale episode heartbeats; it does not
#: hold a one-hour ungrenewed grant.
LEASE_TTL_SECONDS = 900.0
CLOCK_SKEW_TOLERANCE_SECONDS = 5.0
HANDSHAKE_TTL_SECONDS = 900.0

#: One 30-member optimizer wave, exactly what `TargetSpec.scale_leases` says.
ADVERTISED_CONCURRENCY = 30

#: The scored state is the state at the horizon: the workspace is frozen before
#: the verifier is dispatched, and the verifier writes its reward outside the
#: agent-writable tree. Nothing that happens after the horizon is credited, so
#: the declared settlement window is zero and the receipt says so. Declaring a
#: window the length of the verifier would claim the opposite.
SETTLEMENT_WINDOW_SECONDS = 0.0

AGENT_INSTANCE_ID = "instance-0"
ROLE_ID = "swe_agent"
POLICY_TYPE_ID = "policy-0"
TEAM_ID = "team-0"
PARAMETER_GROUP_ID = "pg-0"

#: The rule a compacted turn declares. It names the harness, the threshold that
#: fired and how much was kept, so a reader of the trace alone can tell why a
#: prompt stopped being a prefix of the one before it.
COMPACTION_RULE = (
    f"mini_swe.transcript_compaction.v1"
    f":threshold={COMPACTION_THRESHOLD_TOKENS}"
    f":keep={COMPACTION_KEEP_MESSAGES}"
)

COMPACTION_SUMMARY_TEMPLATE = (
    "Context compacted by the mini-SWE harness. The task statement and "
    "recent turns are preserved. Earlier shell commands, oldest first:\n- "
    "{commands}\n\nContinue by replying with exactly one fenced bash block "
    "containing one actual shell command. Never put prose, YAML, or raw data "
    "in the block."
)

OPENING_TEMPLATE = (
    "{instruction}\n\nWorkspace: {workspace}\nYou have at most {max_steps} commands."
)

RECOVERY_TURN = (
    "Your previous reply did not contain a safe, recognizable shell command. Do "
    "not emit prose, raw data, YAML, or file contents as the command. Reply with "
    "exactly one fenced bash block containing an actual shell command."
)


class TBLiteCispoError(RuntimeError):
    """The CISPO target refused. Never degrade one of these into a reward."""


class TBLiteCispoUndeclarable(TBLiteCispoError):
    """A fact the contract makes mandatory is not available in this deployment."""


# --------------------------------------------------------------------------- #
# Build identity
# --------------------------------------------------------------------------- #


def container_image_digest() -> str:
    """The build a receipt has to be able to name.

    A baked image passes its own digest in ``SYNTH_CONTAINER_IMAGE_DIGEST``. With
    none supplied the identity is the digest of this task package's sources,
    which is a real, checkable identity of the code that answered -- not a
    placeholder that would let two different builds sign the same receipt.
    """

    supplied = (os.environ.get(IMAGE_DIGEST_ENV) or "").strip()
    if supplied:
        return supplied
    digest = hashlib.sha256()
    package = Path(__file__).resolve().parent
    for path in sorted(package.glob("*.py")):
        digest.update(path.name.encode("utf-8"))
        digest.update(path.read_bytes())
    # Named for what it is. A bare ``sha256:`` here would read as an image
    # digest this process never saw.
    return f"source.sha256:{digest.hexdigest()}"


def prompt_program_digest() -> str:
    """The pinned identity of the rendering this container owns.

    The mini-SWE system turn as the harness writes it, the opening and recovery
    templates, the observation truncation limit, and the compaction rule with
    both of its thresholds. Anything that changes what the policy is asked --
    including *when* its transcript is cut -- changes this digest, and with it the
    renderer fingerprint the handshake matches on.
    """

    rule = json.dumps(
        {
            "profile": RENDERER_PROFILE_ID,
            "system": SYSTEM_PROMPT,
            "opening_template": OPENING_TEMPLATE,
            "recovery_turn": RECOVERY_TURN,
            "finish_marker": FINISH_MARKER,
            "output_limit": OUTPUT_LIMIT,
            "max_steps": MAX_STEPS,
            "max_tokens": MAX_TOKENS,
            "compaction_rule": COMPACTION_RULE,
            "compaction_summary_template": COMPACTION_SUMMARY_TEMPLATE,
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return "sha256:" + hashlib.sha256(rule.encode("utf-8")).hexdigest()


def _declared_stop_token_ids() -> tuple[int, ...]:
    raw = (os.environ.get(STOP_TOKEN_IDS_ENV) or "").strip()
    if not raw:
        return ()
    try:
        return tuple(int(item) for item in raw.replace(" ", "").split(",") if item)
    except ValueError as exc:
        raise TBLiteCispoUndeclarable(
            f"{STOP_TOKEN_IDS_ENV}={raw!r} is not a comma-separated list of token ids"
        ) from exc


def renderer_profile(
    *,
    tokenizer_id: str = "",
    tokenizer_digest: str = "",
    stop_token_ids: Sequence[int] = (),
    canary_digest: str = "",
) -> RendererProfileDeclaration:
    """The pinned renderer identity, half owned here and half declared to us.

    ``profile_id``, ``package``, ``package_version`` and ``config_digest`` are
    this container's own: they pin the mini-SWE prompt program. ``tokenizer_id``,
    ``tokenizer_digest`` and ``stop_token_ids`` belong to the sampler the
    deployment binds, because ``message_in_capture_out`` means the tokens come
    back from that sampler and are never produced here. Absent, they are a
    refusal rather than a plausible default.
    """

    resolved_tokenizer = str(tokenizer_id or os.environ.get(TOKENIZER_ID_ENV) or "").strip()
    resolved_digest = str(
        tokenizer_digest or os.environ.get(TOKENIZER_DIGEST_ENV) or ""
    ).strip()
    resolved_stops = tuple(int(item) for item in stop_token_ids) or _declared_stop_token_ids()
    missing = [
        name
        for name, value in (
            (TOKENIZER_ID_ENV, resolved_tokenizer),
            (TOKENIZER_DIGEST_ENV, resolved_digest),
            (STOP_TOKEN_IDS_ENV, resolved_stops),
        )
        if not value
    ]
    if missing:
        raise TBLiteCispoUndeclarable(
            "this container renders a conversation, not tokens: the tokenizer identity "
            f"is a property of the sampler the deployment binds. Missing {missing}."
        )
    return RendererProfileDeclaration(
        profile_id=RENDERER_PROFILE_ID,
        package="harbor_tblite",
        package_version=f"{TASKSET_ID}.v1",
        config_digest=prompt_program_digest(),
        tokenizer_id=resolved_tokenizer,
        tokenizer_digest=resolved_digest,
        stop_token_ids=resolved_stops,
        modalities=("text",),
        add_generation_prompt=True,
        canary_digest=str(canary_digest),
    )


# --------------------------------------------------------------------------- #
# Discovery: the digest-pinned trials this image already bakes
# --------------------------------------------------------------------------- #


@dataclass(frozen=True, slots=True)
class TrialPin:
    """One baked TBLite trial, as ``pins.toml`` and the corpus jointly pin it."""

    slug: str
    task_id: str
    split: str
    agent_image: str
    verifier_image: str
    workspace: str
    instruction_text: str
    instruction_digest: str
    agent_timeout_seconds: float = AGENT_TIMEOUT_SECONDS
    verifier_timeout_seconds: float = VERIFIER_TIMEOUT_SECONDS
    reward_path: str = "verifier/reward.txt"
    result_path: str = "verifier/reward.txt"
    logs_mount: str = "/logs"
    verify_command: tuple[str, ...] = ("bash", "-lc", "/tests/test.sh")

    @property
    def content_digest(self) -> str:
        """The row's own content, addressed.

        The two image ids are in it because a trial re-baked from a changed
        Dockerfile is a different task, and the instruction digest is in it
        because an agent handed a different objective is solving a different
        problem. What is deliberately *not* in it is anything read out of the
        verifier image: the hidden tests are the answer key, and discovery is not
        the place to publish one.
        """

        return task_content_digest(
            {
                "taskset_id": TASKSET_ID,
                "task_id": self.task_id,
                "slug": self.slug,
                "split": self.split,
                "agent_image": self.agent_image,
                "verifier_image": self.verifier_image,
                "workspace": self.workspace,
                "instruction_digest": self.instruction_digest,
            }
        )

    def task_row(self) -> TaskRow:
        return TaskRow(
            task_id=self.task_id,
            content_digest=self.content_digest,
            topology_ref=TOPOLOGY_ID,
            task_family=TASK_FAMILY,
        )


def heldout_slugs() -> frozenset[str]:
    """The slugs the deployment holds out, or none.

    OpenThoughts-TBLite ships no split of its own, so this container does not
    invent one. A deployment that wants a paired train/heldout evaluation names
    the held-out slugs; with none named the taskset declares a single ``train``
    split, which is the honest description of a corpus with no split.
    """

    raw = (os.environ.get(HELDOUT_TASKS_ENV) or "").strip()
    if not raw:
        return frozenset()
    return frozenset(item.strip() for item in raw.split(",") if item.strip())


def declared_trials(*, corpus_root: Path | None = None) -> tuple[TrialPin, ...]:
    """One row per baked trial whose instruction the corpus actually carries.

    A pin with no readable ``instruction.md`` is skipped for the same reason
    ``trials.trial_images`` skips it: the agent would be handed a directory and
    no objective, and an episode with no objective is not the task the row names.
    """

    root = corpus_root if corpus_root is not None else CORPUS_ROOT
    held = heldout_slugs()
    rows: list[TrialPin] = []
    for slug, pin in sorted(pins().items()):
        instruction = root / slug / "instruction.md"
        if not instruction.is_file():
            continue
        text = instruction.read_text(encoding="utf-8", errors="replace")[:30000]
        split = str(pin.get("split") or "").strip() or (
            HELDOUT_SPLIT if slug in held else TRAIN_SPLIT
        )
        rows.append(
            TrialPin(
                slug=slug,
                task_id=f"tblite/{slug}",
                split=split,
                agent_image=str(pin["agent"]),
                verifier_image=str(pin["verifier"]),
                workspace=str(pin.get("workspace") or "/app"),
                instruction_text=text,
                instruction_digest="sha256:"
                + hashlib.sha256(text.encode("utf-8")).hexdigest(),
                agent_timeout_seconds=float(
                    pin.get("agent_timeout_seconds") or AGENT_TIMEOUT_SECONDS
                ),
                verifier_timeout_seconds=float(
                    pin.get("verifier_timeout_seconds") or VERIFIER_TIMEOUT_SECONDS
                ),
            )
        )
    return tuple(rows)


def declared_splits(trials: Sequence[TrialPin]) -> tuple[str, ...]:
    """The splits the rows actually populate, in a stable order."""

    present = {trial.split for trial in trials}
    ordered = [split for split in (TRAIN_SPLIT, HELDOUT_SPLIT) if split in present]
    ordered.extend(sorted(present - set(ordered)))
    return tuple(ordered)


def taskset_version(trials: Sequence[TrialPin]) -> str:
    """A version that moves when any pinned trial does.

    A taskset version that stayed put across a re-bake would let two runs over
    different images claim the same taskset.
    """

    payload = json.dumps(
        [
            {"task_id": trial.task_id, "content_digest": trial.content_digest}
            for trial in trials
        ],
        sort_keys=True,
        separators=(",", ":"),
    )
    return "sha256:" + hashlib.sha256(payload.encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------- #
# The nested-Docker boundary
# --------------------------------------------------------------------------- #


@dataclass(frozen=True, slots=True)
class CommandOutcome:
    """One shell command the agent ran in the extracted workspace."""

    exit_code: int
    stdout: str
    stderr: str
    duration_seconds: float

    def to_result(self) -> dict[str, Any]:
        """The shape ``mini_swe._observation_text`` renders."""

        return {
            "exit_code": self.exit_code,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "duration_seconds": round(self.duration_seconds, 3),
        }


@dataclass(frozen=True, slots=True)
class VerifierOutcome:
    """What the second sibling reported. Its number is the reward, or none is."""

    handle: str
    container: str
    image: str
    exit_code: int
    reward: float | None
    result: dict[str, Any] = field(default_factory=dict)
    isolation_mechanism: str = "separate_verifier_image"
    workspace_content_digest: str = ""
    started_at_offset_seconds: float = 0.0
    finished_at_offset_seconds: float = 0.0


class AgentWorkspace(Protocol):
    """The extracted, agent-writable tree for one attempt."""

    workspace_id: str

    def run(self, command: str, *, timeout_seconds: float) -> CommandOutcome: ...

    def content_digest(self) -> str: ...

    def patch(self) -> str: ...

    def residual_processes(self) -> tuple[str, ...]: ...

    def release(self) -> None: ...


class TrialSubstrate(Protocol):
    """Where a trial's two sibling containers come from.

    Extraction and verification are the only two places this image touches the
    host daemon, and they are the two places a conformance run must not. Both are
    here, behind one seam, so an unpaid run replaces exactly the Docker boundary
    and nothing else about the episode.
    """

    def extract(self, *, trial: TrialPin, rollout_id: str) -> AgentWorkspace: ...

    def submit_verifier(
        self, *, trial: TrialPin, workspace: AgentWorkspace, rollout_id: str
    ) -> str: ...

    def poll_verifier(self, handle: str) -> VerifierOutcome | None: ...

    def ready(self) -> tuple[bool, str]: ...


class HostDockerSubstrate:
    """The deployed boundary: two sibling ``docker run`` invocations.

    This is the same sequence ``NestedTrialRuntime`` already runs on this image,
    with one difference that the deferred contract requires: the verifier is
    started **detached** and polled, because the reward is not readable when the
    episode ends and pretending otherwise is what the deferred capability exists
    to avoid.

    Extraction uses ``--network none``; the verifier reuses Docker's one shared
    default bridge, which is why thirty concurrent attempts do not exhaust
    OrbStack's interface table. Neither is exercised by this image's conformance
    tests: they start no container, by design.
    """

    def __init__(self, *, binary: str = "docker") -> None:
        self._binary = binary
        # A handle is only a container name; reading the grade back needs the
        # trial that declared where the number is written and the logs directory
        # it was written to. Keeping that here is what lets `poll_verifier` take
        # a handle and nothing else.
        self._dispatched: dict[str, tuple[TrialPin, "HostDockerWorkspace"]] = {}

    def ready(self) -> tuple[bool, str]:
        health = nested_health()
        if str(health.get("status") or "") != "ok":
            return False, str(health.get("reason") or "nested_substrate_unavailable")
        return True, "ok"

    def extract(self, *, trial: TrialPin, rollout_id: str) -> AgentWorkspace:
        workspace = HostWorkspace.from_env()
        rollout_dir = workspace.rollout_dir(rollout_id)
        target = rollout_dir / "workspace"
        baseline = rollout_dir / "baseline"
        for path in (target, baseline):
            if path.exists():
                shutil.rmtree(path)
        target.mkdir(parents=True)
        NestedTrial(
            image=trial.agent_image,
            rollout_id=rollout_id,
            command=("bash", "-lc", f"cp -a {trial.workspace}/. /out/"),
            mounts={str(workspace.to_host(target)): "/out"},
            network="none",
            timeout_seconds=600.0,
        ).run()
        if not any(target.iterdir()):
            raise TBLiteCispoError("nested_workspace_extract_empty")
        # The pristine copy is what makes a patch a patch. Without it the
        # "patch" artifact could only be a listing of the final tree, which is
        # not evidence of what the agent changed.
        shutil.copytree(target, baseline)
        return HostDockerWorkspace(
            workspace_id=rollout_id,
            root=target,
            baseline=baseline,
            host_root=workspace.to_host(target),
            logs_dir=rollout_dir / "logs",
            host_logs_dir=workspace.to_host(rollout_dir / "logs"),
        )

    def submit_verifier(
        self, *, trial: TrialPin, workspace: AgentWorkspace, rollout_id: str
    ) -> str:
        assert isinstance(workspace, HostDockerWorkspace)
        logs = workspace.logs_dir
        if logs.exists():
            shutil.rmtree(logs)
        logs.mkdir(parents=True)
        name = f"synth-verify-{platform_id()}-{rollout_id}"[:60]
        NestedTrial(
            image=trial.verifier_image,
            rollout_id=rollout_id,
            command=trial.verify_command,
            mounts={
                str(workspace.host_root): trial.workspace,
                str(workspace.host_logs_dir): trial.logs_mount,
            },
            environment={"HARBOR_LOG_DIR": f"{trial.logs_mount}/verifier"},
            # The verifier reuses the default bridge; a per-trial named network
            # is what exhausts the interface table at thirty concurrent members.
            network=None,
            detach=True,
            timeout_seconds=trial.verifier_timeout_seconds,
            allow_nonzero=True,
        ).run(name=name)
        self._dispatched[name] = (trial, workspace)
        return name

    def poll_verifier(self, handle: str) -> VerifierOutcome | None:
        inspected = subprocess.run(  # noqa: S603
            [self._binary, "inspect", "--format", "{{.State.Running}} {{.State.ExitCode}} {{.Config.Image}}", handle],
            capture_output=True,
            text=True,
            check=False,
        )
        if inspected.returncode != 0:
            raise TBLiteCispoError(f"nested_verifier_lost:{handle}")
        parts = inspected.stdout.strip().split()
        if len(parts) < 3 or parts[0] == "true":
            return None
        exit_code = int(parts[1])
        trial, workspace = self._dispatched[handle]
        # The grade is read from the logs mount, which is outside the tree the
        # agent could write to. A reward file inside the agent's workspace can be
        # planted before the grader ever runs.
        reward = _read_reward(workspace.logs_dir / trial.reward_path)
        return VerifierOutcome(
            handle=handle,
            container=handle,
            image=parts[2],
            exit_code=exit_code,
            reward=reward,
            result={"exit_code": exit_code, "reward_path": trial.reward_path},
        )


@dataclass(slots=True)
class HostDockerWorkspace:
    """The extracted tree, on the host root the daemon and this process share."""

    workspace_id: str
    root: Path
    baseline: Path
    host_root: Path
    logs_dir: Path
    host_logs_dir: Path

    def run(self, command: str, *, timeout_seconds: float) -> CommandOutcome:
        started = time.monotonic()
        completed = subprocess.run(  # noqa: S603
            ["bash", "-lc", command],
            cwd=str(self.root),
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
        return CommandOutcome(
            exit_code=completed.returncode,
            stdout=completed.stdout or "",
            stderr=completed.stderr or "",
            duration_seconds=time.monotonic() - started,
        )

    def content_digest(self) -> str:
        return workspace_tree_digest(self.root)

    def patch(self) -> str:
        completed = subprocess.run(  # noqa: S603
            ["diff", "-ruN", str(self.baseline), str(self.root)],
            capture_output=True,
            text=True,
            check=False,
        )
        return completed.stdout or ""

    def residual_processes(self) -> tuple[str, ...]:
        """Whatever the agent backgrounded that is still holding the tree open."""

        completed = subprocess.run(  # noqa: S603
            ["bash", "-lc", f"fuser -m {self.root} 2>/dev/null || true"],
            capture_output=True,
            text=True,
            check=False,
        )
        return tuple(item for item in completed.stdout.split() if item)

    def release(self) -> None:
        reap_rollout(self.workspace_id)


def _read_reward(path: Path) -> float | None:
    """The verifier's number, or ``None``. An unreadable file is not a zero."""

    try:
        raw = path.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return None
    try:
        value = float(raw.splitlines()[0]) if raw else None
    except (ValueError, IndexError):
        return None
    return value


def workspace_tree_digest(root: Path) -> str:
    """A content address for a directory tree: names and bytes, in a stable order."""

    digest = hashlib.sha256()
    for path in sorted(p for p in root.rglob("*") if p.is_file()):
        digest.update(str(path.relative_to(root)).encode("utf-8"))
        digest.update(b"\0")
        digest.update(hashlib.sha256(path.read_bytes()).digest())
    return "sha256:" + digest.hexdigest()


# --------------------------------------------------------------------------- #
# The sampler seam
# --------------------------------------------------------------------------- #


def read_sample(
    response: Mapping[str, Any],
) -> tuple[str, tuple[int, ...], tuple[int, ...], tuple[float, ...]]:
    """Lift one sampler response into text, prompt ids, generation ids, logprobs.

    Three shapes are read, because three callers already produce them: the
    ``synth_capture`` envelope the optimizer's rollout gateway returns for this
    image today, the flat token receipt ``banking77`` defines, and a
    chat-completions response carrying its capture under ``token_ids`` /
    ``logprobs``. Anything else, or a logprob vector that does not align with the
    generated tokens, is a refusal: recording it anyway would put a call in a
    batch whose importance ratio has no denominator.
    """

    text = ""
    choices = response.get("choices")
    if isinstance(choices, Sequence) and choices:
        message = dict((choices[0] or {}).get("message") or {})
        text = str(message.get("content") or "")
    if not text.strip():
        text = str(response.get("text") or "")
    if not text.strip():
        raise TBLiteCispoError("sampler response carries no generated text")

    capture = response.get("synth_capture")
    if isinstance(capture, Mapping):
        prompt_ids = capture.get("prompt_token_ids")
        generation_ids = capture.get("generation_token_ids")
        logprobs = capture.get("generation_logprobs")
    else:
        prompt_ids = response.get("prompt_token_ids")
        generation_ids = response.get("token_ids")
        if isinstance(generation_ids, Mapping):
            prompt_ids = generation_ids.get("prompt", prompt_ids)
            generation_ids = generation_ids.get("completion")
        logprobs = response.get("log_probs")
        if logprobs is None:
            raw = response.get("logprobs")
            logprobs = raw.get("completion") if isinstance(raw, Mapping) else raw

    prompt_tuple = tuple(int(item) for item in (prompt_ids or ()))
    generation_tuple = tuple(int(item) for item in (generation_ids or ()))
    logprob_tuple = tuple(float(item) for item in (logprobs or ()))
    if not prompt_tuple or not generation_tuple:
        raise TBLiteCispoError(
            "sampler response carries no token receipt; there is nothing to train on"
        )
    if len(logprob_tuple) != len(generation_tuple):
        raise TBLiteCispoError(
            f"sampler returned {len(logprob_tuple)} logprobs for "
            f"{len(generation_tuple)} tokens; an importance ratio has no denominator"
        )
    return text, prompt_tuple, generation_tuple, logprob_tuple


def finish_reason_of(response: Mapping[str, Any], *, generated: int, max_tokens: int) -> str:
    """The finish reason the sampler reported, or the one the lengths prove."""

    raw = str(response.get("finish_reason") or "").strip().lower()
    choices = response.get("choices")
    if not raw and isinstance(choices, Sequence) and choices:
        raw = str((choices[0] or {}).get("finish_reason") or "").strip().lower()
    if raw in {"stop", "stop_token", "eos", "end_turn"}:
        return "stop_token"
    if raw in {"length", "length_cap", "max_tokens"}:
        return "length_cap"
    if raw:
        return "container_abort"
    return "length_cap" if generated >= max_tokens else "stop_token"


class SamplerCallbackTransport:
    """One outbound sampling call, over the transport this image already uses.

    ``urllib``, one bounded timeout, and a typed, secret-free failure. The body
    and headers are the binding's -- the credential lives inside the
    session-scoped origin and is never minted here.
    """

    def __init__(self, *, timeout_seconds: float = 600.0) -> None:
        self._timeout = float(timeout_seconds)

    def post(
        self, url: str, *, headers: Mapping[str, str], body: Mapping[str, Any]
    ) -> Mapping[str, Any]:
        request = urllib.request.Request(
            url,
            data=json.dumps(dict(body)).encode(),
            headers={"content-type": "application/json", **dict(headers)},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self._timeout) as response:
                payload = json.loads(response.read().decode() or "{}")
        except urllib.error.HTTPError as exc:
            # The status is diagnostic; the body may carry provider detail that
            # must not be relayed verbatim into a training event.
            raise TBLiteCispoError(f"cispo_sampler_http_{exc.code}") from exc
        except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
            raise TBLiteCispoError("cispo_sampler_unreachable") from exc
        if not isinstance(payload, Mapping):
            raise TBLiteCispoError("cispo_sampler_response_invalid")
        return dict(payload)


class SamplerOriginReachability:
    """Whether a bound origin answers at all. A reading, never a promise."""

    def __init__(self, *, timeout_seconds: float = 5.0) -> None:
        self._timeout = float(timeout_seconds)

    def reachable(self, origin: SamplerOriginV1) -> bool:
        import socket

        parts = urlsplit(origin.base_url)
        host = parts.hostname
        if not host:
            return False
        port = parts.port or (443 if parts.scheme == "https" else 80)
        try:
            with socket.create_connection((host, int(port)), timeout=self._timeout):
                return True
        except OSError:
            return False


# --------------------------------------------------------------------------- #
# The capability surface installing this target actually supplies
# --------------------------------------------------------------------------- #


def world_capability_surface() -> RuntimeCapabilitySurface:
    """What the TBLite Harbor world publishes on its own.

    It seals a trace, its verifier authors its own reward, it produces a durable
    artifact -- the mutated workspace -- and it does neither checkpoint nor pause
    nor fork, which is the same story ``targets.HARBOR_TBLITE`` tells the shared
    platform through its affordance map.
    """

    return RuntimeCapabilitySurface(
        trace_support=True,
        reward_support=True,
        checkpoint_support=False,
        pause_support=False,
        resume_support=False,
        artifact_support=True,
        multi_actor=False,
        metadata={"world": "openthoughts_tblite", "nested": "host_docker"},
    )


def cispo_capability_surface(
    base: RuntimeCapabilitySurface | None = None,
) -> RuntimeCapabilitySurface:
    """The world's own surface plus exactly what installing this target supplies.

    Four flags turn on here and nothing else does. The CISPO attempt lifecycle
    reads a per-attempt state snapshot (``state_support``) and cancels an attempt
    exactly once (``terminate_support``); the binding routes every model call
    through a session-scoped sampler origin the container proxies
    (``proxied_inference``) and keeps the token ids and per-token behavior
    logprobs that come back (``token_emission``).

    ``token_emission.tokens`` stays false on purpose. The sampler receipts this
    image consumes carry token *ids* and logprobs, not per-token strings, and a
    flag for something nothing publishes is exactly what the contract's
    ``_assert_mandatory`` exists to refuse.
    """

    surface = base if base is not None else world_capability_surface()
    return replace(
        surface,
        state_support=True,
        terminate_support=True,
        proxied_inference=True,
        token_emission=TokenEmissionCapabilities(
            token_ids=True,
            tokens=False,
            logprobs=True,
            metadata={"source": "tblite_mini_swe_sampler_capture"},
        ),
        metadata={**dict(surface.metadata), "cispo_target": TARGET_SCHEMA_VERSION},
    )


# --------------------------------------------------------------------------- #
# The declaration
# --------------------------------------------------------------------------- #


def tblite_cispo_declaration(
    *,
    trials: Sequence[TrialPin],
    profile: RendererProfileDeclaration | None = None,
    image_digest: str = "",
    advertised_concurrency: int = ADVERTISED_CONCURRENCY,
    seconds_per_step: float = SECONDS_PER_STEP,
    lease_ttl_seconds: float = LEASE_TTL_SECONDS,
) -> CispoRuntimeDeclaration:
    """Everything this image declares that a capability surface cannot express."""

    if not trials:
        raise TBLiteCispoUndeclarable(
            "no digest-pinned trial is bakeable in this deployment; a taskset route "
            "that answers with nothing is not discovery"
        )
    return CispoRuntimeDeclaration(
        container_id=CONTAINER_ID,
        container_image_digest=image_digest or container_image_digest(),
        renderer_profile=profile or renderer_profile(),
        discovery=DiscoveryDeclaration(
            taskset_id=TASKSET_ID,
            taskset_version=taskset_version(trials),
            splits=declared_splits(trials),
            task_content_digests=True,
            deterministic_lookup=True,
            duplicate_free=True,
        ),
        policy=PolicyBindingDeclaration(
            binding_transport="message_in_capture_out",
            wire_api="chat_completions",
            session_scoped_sampler_origin=True,
            embeds_credentials=False,
            revision_immutable_after_admission=True,
            records_policy_revision=True,
            probe_binding=True,
        ),
        lifecycle=LifecycleDeclaration(
            advertised_concurrency=int(advertised_concurrency),
            supports_idempotency=True,
            exactly_one_terminal_result=True,
            lease=LeaseDeclaration(
                # The container's own obligation, not a function of the horizon.
                # An hour-scale episode heartbeats; the grant it heartbeats is a
                # quarter of an hour and the straggler deadline never moves.
                ttl_seconds=float(lease_ttl_seconds),
                renewable=True,
                straggler_grace_seconds=STRAGGLER_GRACE_SECONDS,
            ),
        ),
        evidence=EvidenceDeclaration(
            strict_prefix=True,
            masking=True,
            wire_objects=True,
            # The mutated workspace is a directory, not a field. It is inventoried
            # with its content digest and fetched through the declared artifacts
            # route rather than inlined into the job store.
            artifact_by_reference=True,
            tokens_in_tokens_out=False,
        ),
        reward=RewardDeclaration(
            authority="container",
            binds_trace_digest=True,
            # Both, and both are true. The agent's own background processes are
            # stopped before the verifier is dispatched; where something survives
            # that, the state is clipped to the horizon and the attestation says
            # so, which is the declared substitute rather than a silent pass.
            quiescence=True,
            horizon_clipping=True,
            channels=("score",),
            evaluation_plan_id=EVALUATION_PLAN_ID,
            # The verifier reads the frozen tree, so no post-horizon progress is
            # credited and there is no window in which any could be.
            settlement_window_seconds=SETTLEMENT_WINDOW_SECONDS,
            # The thing this container exists to demonstrate: the agent and the
            # verifier are two workloads, so the measure is not readable when the
            # episode ends. Advertised, never inferred from the task name.
            deferred_scoring=True,
        ),
        recovery=RecoveryDeclaration(restart=True, stale_discard=True),
        topology=TopologyDeclaration(
            topology_id=TOPOLOGY_ID,
            turn_model="sequential",
            actuation_model="direct_action",
            reward_relation="cooperative",
            agent_instances=(
                AgentInstanceDeclaration(
                    agent_instance_id=AGENT_INSTANCE_ID,
                    role_id=ROLE_ID,
                    policy_type_id=POLICY_TYPE_ID,
                    team_id=TEAM_ID,
                    trainable=True,
                ),
            ),
            teams=(TeamDeclaration(team_id=TEAM_ID, trainable=True, minimum_viable_roster=1),),
            horizon=HorizonDeclaration(
                horizon_kind="steps",
                value=float(MAX_STEPS),
                seconds_per_unit=float(seconds_per_step),
                grace_seconds=STRAGGLER_GRACE_SECONDS,
            ),
            communication_channels=(),
            parameter_groups={POLICY_TYPE_ID: PARAMETER_GROUP_ID},
        ),
        clock_skew_tolerance_seconds=CLOCK_SKEW_TOLERANCE_SECONDS,
    )


# --------------------------------------------------------------------------- #
# One attempt: one trial, one mini-SWE episode, one deferred verifier
# --------------------------------------------------------------------------- #


# --------------------------------------------------------------------------- #
# The unpaid binding
# --------------------------------------------------------------------------- #


@dataclass(frozen=True, slots=True)
class ProbeAttemptBinding:
    """A bound probe, shaped like a sampler binding for the attempt machine.

    The probe binding is issued by ``CispoHandshakeAdapter`` and kept in its own
    registry, because the sampler registry cannot hold it: a probe has no
    sampler origin, and every entry in that registry is keyed by one. Admission
    therefore looks there first, and wraps what it finds in this, which answers
    everything the attempt machine reads off a binding -- behavior identity, the
    topology slot the calls are attributed to, and whether the evidence may be
    trained on -- so the machine needs no branch for the unpaid kind.

    ``origin`` stays ``None`` on purpose rather than being filled with a
    plausible-looking origin: a synthetic one would carry an absolute URL and a
    credential, neither of which exists, and every path that dispatches would
    then use them. ``origin is None`` is the one-bit structural fact that a
    probe reaches no provider and spends nothing.
    """

    binding_id: str
    payload: Mapping[str, Any]

    @property
    def _behavior(self) -> Mapping[str, Any]:
        return self.payload.get("behavior") or {}

    # -- what kind of binding this is ------------------------------------- #

    @property
    def policy_kind(self) -> str:
        return str(self.payload.get("policy_kind") or self.payload.get("kind") or "probe")

    @property
    def probe(self) -> bool:
        return True

    @property
    def trainable(self) -> bool:
        return False

    @property
    def origin(self) -> None:
        """No origin, and not an oversight: see the class docstring."""

        return None

    @property
    def dispatchable(self) -> bool:
        """A probe is always dispatchable, because it dispatches nowhere."""

        return True

    # -- behavior identity ------------------------------------------------ #

    @property
    def renderer_profile(self) -> RendererProfileV1:
        """The renderer the probe's tokens are attributed to, as a typed profile.

        The bind response carries it as a payload because that is what crossed
        the wire; the attempt machine reads ``.stop_token_ids`` and
        ``.fingerprint`` off it, so it is rebuilt here rather than handed on as
        a mapping that would fail on the first attribute.
        """

        raw = dict(
            self._behavior.get("renderer_profile")
            or self.payload.get("renderer_profile")
            or {}
        )
        return RendererProfileV1(
            profile_id=str(raw.get("profile_id") or ""),
            package=str(raw.get("package") or ""),
            package_version=str(raw.get("package_version") or ""),
            config_digest=str(raw.get("config_digest") or ""),
            tokenizer_id=str(raw.get("tokenizer_id") or ""),
            tokenizer_digest=str(raw.get("tokenizer_digest") or ""),
            stop_token_ids=tuple(int(item) for item in (raw.get("stop_token_ids") or ())),
            modalities=tuple(str(item) for item in (raw.get("modalities") or ("text",))),
            add_generation_prompt=bool(raw.get("add_generation_prompt", True)),
        )

    @property
    def model_family(self) -> str:
        return str(self._behavior.get("model_family") or "")

    @property
    def model_id(self) -> str:
        return str(self._behavior.get("model_id") or "")

    @property
    def policy_revision(self) -> int:
        return int(self._behavior.get("policy_revision") or 0)

    @property
    def wire_api(self) -> str:
        return str(self._behavior.get("wire_api") or "chat_completions")

    @property
    def sampling_transport(self) -> str:
        return str(self._behavior.get("sampling_transport") or "message_in_capture_out")

    @property
    def sampling(self) -> SamplingProfileV1:
        raw = dict(self._behavior.get("sampling") or {})
        max_tokens = raw.get("max_tokens")
        seed = raw.get("seed")
        return SamplingProfileV1(
            temperature=float(raw.get("temperature", 1.0)),
            top_p=float(raw.get("top_p", 1.0)),
            max_tokens=None if max_tokens is None else int(max_tokens),
            seed=None if seed is None else int(seed),
        )

    def behavior_binding(self) -> BehaviorBindingV1:
        """A method, not a property: the sampler binding spells it that way."""

        return BehaviorBindingV1(
            renderer_profile=self.renderer_profile,
            model_family=self.model_family,
            model_id=self.model_id,
            policy_revision=self.policy_revision,
            wire_api=self.wire_api,
            sampling_transport=self.sampling_transport,
            sampling=self.sampling,
        )

    @property
    def behavior_fingerprint(self) -> str:
        """The fingerprint the container published when it issued this binding.

        Taken from the payload rather than recomputed: what the evidence is
        stamped with has to be the value the executor was told, or the two
        halves disagree about which behavior produced the tokens.
        """

        return str(
            self.payload.get("behavior_fingerprint") or self.behavior_binding().fingerprint
        )

    @property
    def behavior_identity(self) -> str:
        """The same pin ``SamplerBinding`` computes, over the same fields."""

        return canonical_digest(
            {
                "policy_revision": int(self.policy_revision),
                "behavior_fingerprint": self.behavior_fingerprint,
                "model_family": self.model_family,
                "model_id": self.model_id,
                "wire_api": self.wire_api,
                "sampling_transport": self.sampling_transport,
                "renderer_fingerprint": self.renderer_profile.fingerprint,
            },
            length=32,
        )

    # -- topology slot ---------------------------------------------------- #

    @property
    def agent_instance_id(self) -> str | None:
        value = self.payload.get("agent_instance_id")
        return None if value is None else str(value)

    @property
    def team_id(self) -> str | None:
        value = self.payload.get("team_id")
        return None if value is None else str(value)

    @property
    def parameter_group_id(self) -> str | None:
        value = self.payload.get("parameter_group_id")
        return None if value is None else str(value)


class ProbePolicySession:
    """Drives a probe attempt through the same episode a paid one walks.

    The paid session reads the per-attempt call identity off the binding's
    sampler origin. A probe has no origin -- that absence is exactly what makes
    it unable to spend -- so this session mints the identity itself, from the
    attempt it is running, and hands back a :class:`ModelCallRecordV1` of the
    same type the paid session hands back. The episode therefore reads
    ``record.proxy_request_id`` either way and needs no branch.

    The wire objects it persists are marked synthetic and name no provider, so
    a reader can never mistake probe evidence for the real thing.
    """

    def __init__(self, binding: Any, *, rollout_id: str, transport: Any) -> None:
        self._binding = binding
        self._rollout_id = str(rollout_id)
        self._transport = transport
        self._calls: list[ModelCallRecordV1] = []
        self._lock = threading.Lock()

    @property
    def binding(self) -> Any:
        return self._binding

    @property
    def calls(self) -> tuple[ModelCallRecordV1, ...]:
        return tuple(self._calls)

    @property
    def endpoint(self) -> str:
        """A ``probe://`` endpoint: an address no http client could dial."""

        return f"probe://{self._binding.binding_id}/v1/chat/completions"

    def request(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        del payload
        return {
            "synthetic": True,
            "provider": None,
            "probe": True,
            "policy_kind": PROBE_POLICY_KIND,
            "wire_api": self._binding.wire_api,
        }

    def call(self, payload: Mapping[str, Any]) -> tuple[ModelCallRecordV1, Mapping[str, Any]]:
        # The transport still insists on an Authorization header, because a real
        # one always carries the session credential. A probe has none, so it
        # presents its own binding id: the header is present and provably not a
        # provider key.
        response = self._transport.post(
            self.endpoint,
            headers={"Authorization": f"Probe {self._binding.binding_id}"},
            body={"model": self._binding.model_id, **dict(payload)},
        )
        if not isinstance(response, Mapping):
            raise TBLiteCispoError("the probe sampler returned a non-object response")
        marked = {
            **dict(response),
            "synthetic": True,
            "provider": None,
            "probe": True,
            "paid": False,
        }
        with self._lock:
            index = len(self._calls)
            record = ModelCallRecordV1(
                call_index=index,
                binding_id=self._binding.binding_id,
                # No proxy was reached, so there is no provider-issued id to
                # carry. The identity is still per attempt and per turn.
                proxy_request_id=f"{self._rollout_id}:proxy-{index + 1}",
                policy_revision=int(self._binding.policy_revision),
                behavior_fingerprint=self._binding.behavior_fingerprint,
                behavior_identity=self._binding.behavior_identity,
                agent_instance_id=self._binding.agent_instance_id,
                trainable=False,
                wire_api=self._binding.wire_api,
                sampling_transport=self._binding.sampling_transport,
                endpoint=self.endpoint,
                request_digest=canonical_digest(self.request(payload), length=32),
                response_digest=canonical_digest(marked, length=32),
            )
            self._calls.append(record)
        return record, marked


def _assert_probe_evidence_refused(evidence: SealedEvidenceV1) -> None:
    """A probe's evidence must be refused for training, by its own fields.

    ``validate`` is the training gate; probe evidence that *passed* it would be
    evidence a trainer could not tell from the real thing. So for a probe the
    same gate is run in the other direction, and the container refuses to seal
    an attempt that is missing one of the marks rather than putting a record on
    the wire that a reader could mistake for real.
    """

    if not evidence.rollout_id.startswith(PROBE_ROLLOUT_PREFIX):
        raise TBLiteCispoError(
            f"probe attempt {evidence.rollout_id!r} does not use the "
            f"{PROBE_ROLLOUT_PREFIX!r} id namespace"
        )
    if not evidence.episodes:
        raise TBLiteCispoError(f"probe attempt {evidence.rollout_id} produced no episode")
    for call in evidence.calls:
        assert_wire_not_flattened(call)
        if call.trainable:
            raise TBLiteCispoError(f"probe call {call.call_id} is marked trainable")
        if call.author_kind != "policy":
            # A judge, verifier or opponent span is foreign-authored and already
            # carries its own refusal -- it was never the policy's generation,
            # probe or not. Demanding the probe's marks on it would be demanding
            # that the container lie about who wrote it.
            continue
        if call.token_capture_provenance != PROBE_TOKEN_CAPTURE_PROVENANCE:
            raise TBLiteCispoError(
                f"probe call {call.call_id} declares provenance "
                f"{call.token_capture_provenance!r}, not "
                f"{PROBE_TOKEN_CAPTURE_PROVENANCE!r}"
            )
        if not call.wire_response.get("synthetic"):
            raise TBLiteCispoError(
                f"probe call {call.call_id} persists a wire object that does not "
                "declare itself synthetic"
            )
        try:
            call.validate_for_training()
        except EvidenceError:
            continue
        raise TBLiteCispoError(
            f"probe call {call.call_id} passes the training gate; probe evidence "
            "would be indistinguishable from real evidence"
        )
    for episode in evidence.episodes:
        if not episode.probe:
            raise TBLiteCispoError(f"probe episode {episode.rollout_id} is not marked probe")
        try:
            episode.validate()
        except EvidenceError:
            continue
        raise TBLiteCispoError(f"probe episode {episode.rollout_id} passes the training gate")


@dataclass(frozen=True, slots=True)
class AttemptPlan:
    """What one accepted attempt is: a trial, a seed, and one bound policy."""

    rollout_id: str
    trial: TrialPin
    binding: SamplerBinding | ProbeAttemptBinding
    handshake_id: str
    agreement_digest: str
    seed: int = 0
    group_id: str = ""
    sample_index: int = 0
    run_id: str = ""


@dataclass(frozen=True, slots=True)
class CompactionEvent:
    """One transcript cut, as the trace and the event stream both record it."""

    step: int
    branch_id: str
    parent_branch_id: str
    removed_message_indices: tuple[int, ...]
    retained_messages: int
    prompt_tokens_at_trigger: int
    divergence_index: int = -1


@dataclass(frozen=True, slots=True)
class EpisodeResult:
    """What the agent half produced. The measure is deliberately not here."""

    rollout_id: str
    evidence: SealedEvidenceV1
    workspace: AgentWorkspace
    workspace_content_digest: str
    patch: str
    patch_digest: str
    steps: int
    commands: int
    finished: bool
    compactions: tuple[CompactionEvent, ...]
    snapshot: dict[str, Any] = field(default_factory=dict)


def _common_prefix_length(left: Sequence[int], right: Sequence[int]) -> int:
    length = 0
    for a, b in zip(left, right, strict=False):
        if a != b:
            break
        length += 1
    return length


class TBLiteAttemptRuntime:
    """The ``cispo_rollout.RolloutRuntime`` seam, over one nested TBLite trial.

    ``start`` runs the whole *agent* episode: extract the digest-pinned
    workspace, drive the mini-SWE loop against the bound sampler, execute one
    shell command per turn, compact the transcript at the declared threshold, and
    seal one immutable inference call per sampler call. It stops there. The
    verifier is a second workload and does not run in this call: the reward is
    not readable when the episode ends, which is the whole reason this container
    declares deferred scoring.

    ``poll`` reports that the episode stopped producing and never finalizes on
    its own: the attempt is terminal when the horizon is attested, which is
    ``finalize``'s job. Conflating the two is how a reward comes to describe
    whatever was still running afterwards.
    """

    def __init__(
        self,
        *,
        transport: SamplerTransport,
        substrate: TrialSubstrate,
        max_steps: int = MAX_STEPS,
        max_tokens: int = MAX_TOKENS,
        temperature: float = 1.0,
        command_timeout_seconds: float = COMMAND_TIMEOUT_SECONDS,
        compaction_threshold_tokens: int = COMPACTION_THRESHOLD_TOKENS,
        compaction_keep_messages: int = COMPACTION_KEEP_MESSAGES,
    ) -> None:
        self._transport = transport
        self._substrate = substrate
        self._max_steps = int(max_steps)
        self._max_tokens = int(max_tokens)
        self._temperature = float(temperature)
        self._command_timeout = float(command_timeout_seconds)
        self._threshold = int(compaction_threshold_tokens)
        self._keep = int(compaction_keep_messages)
        self._lock = threading.RLock()
        self._plans: dict[str, AttemptPlan] = {}
        self._results: dict[str, EpisodeResult] = {}
        self._cancelled: dict[str, str] = {}

    # -- plans ------------------------------------------------------------ #

    def register(self, plan: AttemptPlan) -> AttemptPlan:
        with self._lock:
            self._plans[plan.rollout_id] = plan
        return plan

    def plan(self, rollout_id: str) -> AttemptPlan:
        with self._lock:
            found = self._plans.get(rollout_id)
        if found is None:
            raise TBLiteCispoError(f"attempt {rollout_id!r} has no admitted plan")
        return found

    def result(self, rollout_id: str) -> EpisodeResult:
        with self._lock:
            found = self._results.get(rollout_id)
        if found is None:
            raise TBLiteCispoError(
                f"attempt {rollout_id!r} sealed no evidence; missing evidence is a "
                "terminal failure, not a zero-reward trajectory"
            )
        return found

    def evidence(self, rollout_id: str) -> SealedEvidenceV1:
        return self.result(rollout_id).evidence

    # -- the RolloutRuntime protocol -------------------------------------- #

    def start(self, attempt: AttemptRecordV1, log: RolloutEventLog) -> None:
        plan = self.plan(attempt.rollout_id)
        result = self._run_episode(plan, log)
        with self._lock:
            self._results[attempt.rollout_id] = result

    def poll(self, attempt: AttemptRecordV1, log: RolloutEventLog) -> str | None:
        del log
        with self._lock:
            if attempt.rollout_id in self._cancelled:
                return "cancelled"
            finished = attempt.rollout_id in self._results
        return "completed" if finished else None

    def quiesce(self, attempt: AttemptRecordV1) -> tuple[str, ...]:
        """Stop whatever the agent backgrounded in the workspace before grading.

        A mini-SWE turn may end in ``&``. Anything still holding the tree open
        when the verifier mounts it would be environment activity after the
        horizon reaching the reward, so it is named here and the attestation
        clips the state when it cannot be stopped.
        """

        with self._lock:
            found = self._results.get(attempt.rollout_id)
        if found is None:
            return ()
        return tuple(found.workspace.residual_processes())

    def horizon_snapshot(self, attempt: AttemptRecordV1) -> Mapping[str, Any]:
        with self._lock:
            found = self._results.get(attempt.rollout_id)
        if found is None:
            return {"rollout_id": attempt.rollout_id, "steps": 0, "state": "unstarted"}
        return dict(found.snapshot)

    def cancel(self, attempt: AttemptRecordV1, reason: str) -> None:
        with self._lock:
            self._cancelled[attempt.rollout_id] = str(reason)
            found = self._results.get(attempt.rollout_id)
        if found is not None:
            found.workspace.release()

    # -- the episode ------------------------------------------------------ #

    def _run_episode(self, plan: AttemptPlan, log: RolloutEventLog) -> EpisodeResult:
        binding = plan.binding
        probe = bool(getattr(binding, "probe", False))
        if binding.origin is None and not probe:
            raise TBLiteCispoError(
                f"attempt {plan.rollout_id!r} is bound to a policy with no sampler origin"
            )
        trial = plan.trial
        workspace = self._substrate.extract(trial=trial, rollout_id=plan.rollout_id)
        log.append(
            "nested.workspace.extracted",
            {
                "rollout_id": plan.rollout_id,
                "trial_image_id": trial.task_id,
                "image": trial.agent_image,
                "workspace": trial.workspace,
                "nested": "host_docker",
            },
        )
        log.append(
            "env.episode.opened",
            {
                "rollout_id": plan.rollout_id,
                "task_id": trial.task_id,
                "split": trial.split,
                "seed": plan.seed,
                "max_steps": self._max_steps,
            },
        )

        builder = CispoEvidenceBuilder(
            rollout_id=plan.rollout_id,
            task_id=trial.task_id,
            binding=binding.behavior_binding(),
            seed=plan.seed,
            group_id=plan.group_id,
            sample_index=plan.sample_index,
            # The builder is what stamps the episode as probe. It is told once,
            # here, rather than having each mark applied by hand further down
            # where one could be forgotten.
            probe=probe,
        )
        # A probe reaches no provider, so it has no origin to reach one
        # through. It still walks this same episode, against the deterministic
        # sampler, which is the point: the unpaid path must exercise the paid one.
        session = (
            ProbePolicySession(
                binding, rollout_id=plan.rollout_id, transport=self._transport
            )
            if probe
            else BoundPolicySession(binding, transport=self._transport)
        )

        messages: list[dict[str, Any]] = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": OPENING_TEMPLATE.format(
                    instruction=trial.instruction_text.strip(),
                    workspace=trial.workspace,
                    max_steps=self._max_steps,
                ),
            },
        ]
        commands_run: list[str] = []
        compactions: list[CompactionEvent] = []
        branch_id = "root"
        parent_branch_id: str | None = None
        pending_cut: dict[str, Any] | None = None
        previous_call: InferenceCallV1 | None = None
        steps = 0
        finished = False

        try:
            while steps < self._max_steps:
                payload = {
                    "messages": [dict(item) for item in messages],
                    "max_tokens": self._max_tokens,
                    "temperature": self._temperature,
                }
                wire_request = session.request(payload)
                record, response = session.call(payload)
                text, prompt_ids, generation_ids, logprobs = read_sample(response)

                compaction: CompactionProvenanceV1 | None = None
                capture = response.get("synth_capture")
                if isinstance(capture, Mapping):
                    # Rendering owns token-history identity. Prime can re-close
                    # a sampled assistant turn even when the message transcript
                    # only grew, so preserve the gateway's explicit fork.
                    branch_id = str(capture.get("branch_id") or branch_id)
                    raw_parent = capture.get("parent_branch_id")
                    parent_branch_id = (
                        str(raw_parent) if raw_parent is not None else None
                    )
                    raw_compaction = capture.get("compaction")
                    if isinstance(raw_compaction, Mapping):
                        compaction = CompactionProvenanceV1(
                            rule=str(raw_compaction.get("rule") or ""),
                            divergence_index=int(
                                raw_compaction.get("divergence_index") or 0
                            ),
                            removed_message_indices=tuple(
                                int(item)
                                for item in raw_compaction.get("removed_message_indices") or ()
                            ),
                            authored_by_policy=bool(
                                raw_compaction.get("authored_by_policy", False)
                            ),
                        )
                    pending_cut = None
                elif pending_cut is not None:
                    # The divergence index is a fact about tokens, so it is
                    # computed once the compacted prompt actually exists rather
                    # than guessed at the moment the transcript was cut.
                    assert previous_call is not None
                    divergence = _common_prefix_length(
                        previous_call.full_sequence, prompt_ids
                    )
                    compaction = CompactionProvenanceV1(
                        rule=COMPACTION_RULE,
                        divergence_index=divergence,
                        removed_message_indices=tuple(pending_cut["removed"]),
                        # The harness cut the transcript, not the policy. A
                        # policy-authored summary would be a different claim.
                        authored_by_policy=False,
                    )
                    compactions[-1] = replace(compactions[-1], divergence_index=divergence)
                    pending_cut = None

                call = InferenceCallV1(
                    call_id=f"{plan.rollout_id}:call:{steps}",
                    proxy_request_id=record.proxy_request_id,
                    rollout_id=plan.rollout_id,
                    group_id=plan.group_id,
                    sample_index=plan.sample_index,
                    behavior_fingerprint=binding.behavior_fingerprint,
                    policy_revision=int(binding.policy_revision),
                    wire_api=binding.wire_api,
                    sampling_transport=binding.sampling_transport,
                    token_capture_provenance=(
                        PROBE_TOKEN_CAPTURE_PROVENANCE if probe else "engine_meta"
                    ),
                    trainable=not probe,
                    prompt_token_ids=prompt_ids,
                    generation_token_ids=generation_ids,
                    generation_logprobs=logprobs,
                    sampled_mask=tuple(1 for _ in generation_ids),
                    finish_reason=finish_reason_of(
                        response, generated=len(generation_ids), max_tokens=self._max_tokens
                    ),
                    stop_token_ids=tuple(binding.renderer_profile.stop_token_ids),
                    renderer_profile_fingerprint=binding.renderer_profile.fingerprint,
                    branch_id=branch_id,
                    parent_branch_id=parent_branch_id,
                    compaction=compaction,
                    agent_instance_id=binding.agent_instance_id or AGENT_INSTANCE_ID,
                    team_id=binding.team_id or TEAM_ID,
                    role_id=ROLE_ID,
                    policy_type_id=POLICY_TYPE_ID,
                    parameter_group_id=binding.parameter_group_id or PARAMETER_GROUP_ID,
                    effect_tick_start=steps,
                    effect_tick_end=steps + 1,
                    author_kind="policy",
                    wire_request=dict(wire_request),
                    wire_response=dict(response),
                    usage={
                        "prompt_tokens": len(prompt_ids),
                        "completion_tokens": len(generation_ids),
                        # A probe reached no provider, so the usage record says
                        # the request count is zero and nothing was billed,
                        # rather than leaving token counts to read like a bill.
                        **(
                            {"provider_requests": 0, "billed": False}
                            if probe
                            else {"provider_requests": 1}
                        ),
                    },
                    created_at=utc_now(),
                )
                # The builder enforces the strict-prefix rule here. A sampler
                # whose re-render is not a byte-for-byte extension of the last
                # sequence raises, and the attempt fails as an evidence failure
                # rather than producing a batch nothing can be trained from.
                builder.observe(call)
                previous_call = call

                # The raw assistant text goes back into the transcript, byte for
                # byte. Rewriting it -- as the harness does for harmony models --
                # would make the next prompt not a prefix of this sequence, and
                # a rewrite is not a compaction.
                messages.append({"role": "assistant", "content": text})

                command = _extract_command(text)
                rejection = _command_rejection(command)
                if command is None or rejection is not None:
                    messages.append({"role": "user", "content": RECOVERY_TURN})
                    log.append(
                        "span.policy.data",
                        {
                            "channel": "mini_swe",
                            "step": steps,
                            "parse_error": rejection or "no_command",
                        },
                    )
                    steps += 1
                    continue

                if FINISH_MARKER in command:
                    finished = True
                    log.append(
                        "span.policy.data",
                        {"channel": "mini_swe", "step": steps, "event": "finished"},
                    )
                    steps += 1
                    break

                outcome = workspace.run(command, timeout_seconds=self._command_timeout)
                commands_run.append(command)
                messages.append(
                    {
                        "role": "user",
                        "content": _observation_text(outcome.to_result(), OUTPUT_LIMIT),
                    }
                )
                log.append(
                    "span.policy.data",
                    {
                        "channel": "mini_swe",
                        "step": steps,
                        "command": command[:400],
                        "exit_code": outcome.exit_code,
                        "duration_seconds": round(outcome.duration_seconds, 3),
                    },
                )
                steps += 1

                cut = self._maybe_compact(
                    messages,
                    commands_run,
                    prompt_tokens=len(prompt_ids) + len(generation_ids),
                    step=steps,
                    branch_id=branch_id,
                    compactions=compactions,
                )
                if cut is not None:
                    messages = cut["messages"]
                    parent_branch_id = branch_id
                    branch_id = cut["branch_id"]
                    pending_cut = cut
                    log.append("agent.context_compacted", dict(cut["event"]))

            digest = workspace.content_digest()
            patch = workspace.patch()
            patch_digest = "sha256:" + hashlib.sha256(patch.encode("utf-8")).hexdigest()

            evidence = builder.seal(
                terminal_status="completed",
                correlation={
                    "run_id": plan.run_id,
                    "group_id": plan.group_id,
                    "sample_index": plan.sample_index,
                    "seed": plan.seed,
                    "handshake_id": plan.handshake_id,
                    "agreement_digest": plan.agreement_digest,
                    "task_digest": trial.content_digest,
                    "workspace_content_digest": digest,
                    "patch_digest": patch_digest,
                },
            )
            # The container refuses its own invalid evidence here rather than
            # letting a reward describe it later. For a probe the same gate is
            # run in the other direction: ``validate`` is the training gate, and
            # probe evidence that *passed* it would be evidence a trainer could
            # not tell from the real thing.
            if probe:
                _assert_probe_evidence_refused(evidence)
            else:
                evidence.validate()
        except Exception:
            # A failed episode still releases the tree it extracted. Leaving it
            # behind is how a thirty-member wave fills a disk.
            workspace.release()
            raise

        log.append(
            "env.episode.closed",
            {
                "rollout_id": plan.rollout_id,
                "status": "completed",
                "steps": steps,
                "commands": len(commands_run),
                "compactions": len(compactions),
                # Deliberately no reward here: the verifier has not run.
                "scoring": "deferred",
            },
        )
        return EpisodeResult(
            rollout_id=plan.rollout_id,
            evidence=evidence,
            workspace=workspace,
            workspace_content_digest=digest,
            patch=patch,
            patch_digest=patch_digest,
            steps=steps,
            commands=len(commands_run),
            finished=finished,
            compactions=tuple(compactions),
            snapshot={
                "rollout_id": plan.rollout_id,
                "task_id": trial.task_id,
                "split": trial.split,
                "state": "agent_episode_complete",
                "steps": steps,
                "commands": len(commands_run),
                "compactions": len(compactions),
                "declared_finish": finished,
                "workspace_content_digest": digest,
                "patch_digest": patch_digest,
            },
        )

    def _maybe_compact(
        self,
        messages: list[dict[str, Any]],
        commands_run: Sequence[str],
        *,
        prompt_tokens: int,
        step: int,
        branch_id: str,
        compactions: list[CompactionEvent],
    ) -> dict[str, Any] | None:
        """Bound a long transcript, and say exactly what was dropped.

        The rule is the harness's: keep the system turn and the task statement,
        keep the last ``compaction_keep_messages`` turns, and replace everything
        between them with a summary of the commands that were run. What this adds
        is the *record* -- the indices that were removed and the branch the next
        turn opens -- because a prompt that is not a prefix of the one before it
        has to say why or it is an evidence failure.
        """

        if not self._threshold or prompt_tokens < self._threshold:
            return None
        if len(messages) <= self._keep + 2:
            return None
        head = messages[:2]
        tail = messages[-self._keep :]
        removed = tuple(range(2, len(messages) - self._keep))
        summary = COMPACTION_SUMMARY_TEMPLATE.format(
            commands="\n- ".join(str(item)[:240] for item in list(commands_run)[-12:])
        )
        compacted = [*head, {"role": "system", "content": summary}, *tail]
        new_branch = f"compaction-{len(compactions) + 1}"
        event = CompactionEvent(
            step=step,
            branch_id=new_branch,
            parent_branch_id=branch_id,
            removed_message_indices=removed,
            retained_messages=len(compacted),
            prompt_tokens_at_trigger=prompt_tokens,
        )
        compactions.append(event)
        return {
            "messages": compacted,
            "branch_id": new_branch,
            "removed": removed,
            "event": {
                "rollout_id": "",
                "step": step,
                "rule": COMPACTION_RULE,
                "branch_id": new_branch,
                "parent_branch_id": branch_id,
                "removed_messages": len(removed),
                "retained_messages": len(compacted),
                "prompt_tokens_at_trigger": prompt_tokens,
            },
        }


# --------------------------------------------------------------------------- #
# The rollout port
# --------------------------------------------------------------------------- #


class TBLiteRolloutPort(CispoRolloutAdapter):
    """The rollout port with a real TBLite attempt behind it.

    Three things are added to the base adapter and nothing else changes.

    * **Submission admits and starts.** An attempt is gated against its
      handshake, its trial row and its policy binding before the lifecycle sees
      it, and the agent episode runs as part of accepting it -- a container with
      no worker behind ``/rollout`` accepts attempts that never run.
    * **Finalize dispatches the verifier.** Not before: the verifier grades the
      tree as it stood at the horizon, so it may not start until quiescence has
      been attested. Dispatching it *is* the artifact collection the horizon
      budgets for, and it happens inside the attempt's lease.
    * **The reward waits, and says so.** Until the verifier reports, the reward
      route answers ``awaiting_score`` with the reason, which is a different
      answer from an absent reward and a very different one from zero. Once it
      reports, the measure is the verifier's own number, bound to the sealed
      trace and to the digest of the workspace that was graded.
    """

    def __init__(self, target: "TBLiteCispoTarget") -> None:
        super().__init__(
            target.lifecycle,
            evidence_source=target.attempts.evidence,
            reward_source=lambda: target.reward_authority,
            artifact_source=target.artifacts,
        )
        self._target = target

    def cispo_submit_rollout(self, request: Mapping[str, Any]) -> dict[str, Any]:
        plan = self._target.admit_attempt(request)
        merged = dict(request)
        # Admission is what mints the rollout id when the executor did not name
        # one -- it cannot, because the origin it submits is bound first -- so
        # the lifecycle is told the id admission settled on rather than
        # re-reading a field that may not be there.
        merged["rollout_id"] = plan.rollout_id
        if merged.get("horizon") is None:
            # The container's own declared horizon, never an invented one, and
            # with the post-horizon budgets the straggler deadline needs.
            merged["horizon"] = self._target.declared_horizon()
        payload = super().cispo_submit_rollout(merged)
        # Never overwrite the id the lifecycle returned: on a retry it is the
        # original attempt's, and reporting this admission's would turn a
        # deduplicated resubmission into a second logical attempt.
        payload.setdefault("rollout_id", plan.rollout_id)
        if not payload.get("duplicate"):
            self._target.reward_authority.open(
                plan.rollout_id, log=self._lifecycle.log(plan.rollout_id)
            )
            record = self._lifecycle.start(plan.rollout_id)
            payload["state"] = record.state.value
        payload["config_id"] = plan.binding.binding_id
        payload["agent_instance_id"] = plan.binding.agent_instance_id
        payload["team_id"] = plan.binding.team_id
        payload["task_id"] = plan.trial.task_id
        payload["task_content_digest"] = plan.trial.content_digest
        payload["scoring_state"] = self._target.reward_authority.state(
            plan.rollout_id
        ).value
        return payload

    def cispo_rollout_state(self, rollout_id: str) -> dict[str, Any]:
        """Two clocks, both reported: the episode's, and scoring's.

        ``state`` is the attempt -- ``running`` while the agent is producing,
        ``awaiting_score`` once it stops, terminal once the horizon is attested.
        ``scoring_state`` is the reward's, and on this container they are not the
        same question: an attempt can be ``completed`` with its measure still
        unreadable.
        """

        payload = super().cispo_rollout_state(rollout_id)
        payload["scoring_state"] = self._target.reward_authority.state(rollout_id).value
        payload["verifier"] = self._target.verifier_status(rollout_id)
        return payload

    def cispo_finalize_rollout(
        self, rollout_id: str, request: Mapping[str, Any] | None = None
    ) -> dict[str, Any]:
        payload = super().cispo_finalize_rollout(rollout_id, request)
        payload["scoring"] = self._target.dispatch_verifier(rollout_id)
        return payload

    def cispo_terminate_rollout(
        self, rollout_id: str, request: Mapping[str, Any] | None = None
    ) -> dict[str, Any]:
        """Terminate, and seal the receipt that leaves the done boundary.

        The lifecycle knows the terminal result; only the target knows the
        attempt's identity and what it sealed. The executor reads a ``receipt``
        here -- identity plus digests -- and a terminal state that names no
        attempt is not one it can record, so the two are answered together.
        """

        payload = super().cispo_terminate_rollout(rollout_id, request)
        payload["receipt"] = self._receipt(rollout_id, payload.get("terminal") or {})
        return payload

    def _receipt(self, rollout_id: str, terminal: Mapping[str, Any]) -> dict[str, Any]:
        plan = self._target.attempts.plan(rollout_id)
        binding = plan.binding
        try:
            evidence: SealedEvidenceV1 | None = self._target.attempts.evidence(rollout_id)
        except TBLiteCispoError:
            # Terminated before it sealed anything. Absent is not zero: the
            # digests stay empty rather than being filled with a plausible one.
            evidence = None
        origin = getattr(binding, "origin", None)
        if evidence is not None and evidence.calls:
            proxy_request_id = evidence.calls[0].proxy_request_id
        elif origin is not None:
            proxy_request_id = origin.proxy_request_id
        else:
            proxy_request_id = f"{rollout_id}:proxy"
        return {
            "rollout_id": rollout_id,
            "proxy_request_id": proxy_request_id,
            "group_id": plan.group_id,
            "sample_index": int(plan.sample_index),
            "policy_revision": int(binding.policy_revision),
            "behavior_fingerprint": binding.behavior_fingerprint,
            "terminal_status": str(terminal.get("terminal_status") or ""),
            "trace_digest": "" if evidence is None else evidence.trace_digest,
            "evidence_digest": "" if evidence is None else evidence.evidence_digest,
            "handshake_id": plan.handshake_id,
            "agreement_digest": plan.agreement_digest,
            "agent_instance_id": binding.agent_instance_id,
            "team_id": binding.team_id,
            "probe": bool(getattr(binding, "probe", False)),
            "metadata": {
                "task_id": plan.trial.task_id,
                "task_content_digest": plan.trial.content_digest,
                "reason": str(terminal.get("reason") or ""),
            },
        }

    def cispo_reward(self, request: Mapping[str, Any]) -> dict[str, Any]:
        for name in ("measure", "measures"):
            if request.get(name) is not None:
                raise TBLiteCispoError(
                    f"reward request carries {name!r}; this container's verifier is the "
                    "reward authority and the executor never scores locally"
                )
        rollout_id = str(request["rollout_id"])
        result = self._target.attempts.result(rollout_id)
        offered = str(request.get("trace_digest") or "").strip()
        if offered and offered != result.evidence.trace_digest:
            raise TBLiteCispoError(
                f"reward asked to score trace {offered} but attempt {rollout_id} sealed "
                f"{result.evidence.trace_digest}"
            )
        settled = self._target.settled_receipt(rollout_id)
        if settled is not None:
            # Final scoring is idempotent: a second read is the same receipt.
            return dict(settled)

        outcome = self._target.verifier_outcome(rollout_id)
        if outcome is None:
            return self._target.deferred_reward_payload(rollout_id)

        plan = self._target.attempts.plan(rollout_id)
        merged = dict(request)
        merged["trace_digest"] = result.evidence.trace_digest
        merged["metadata"] = {
            **dict(request.get("metadata") or {}),
            **self._target.reward_metadata(plan, result, outcome),
        }
        if outcome.reward is None:
            # The verifier ran and produced no number. That is missing evidence,
            # named as such, and it is not a zero: the receipt carries no channel
            # and refuses validation.
            merged["optimized_team_id"] = None
        else:
            merged["measures"] = {plan.binding.team_id or TEAM_ID: float(outcome.reward)}
            merged["optimized_team_id"] = plan.binding.team_id or TEAM_ID
        return super().cispo_reward(merged)


# --------------------------------------------------------------------------- #
# The admission port
# --------------------------------------------------------------------------- #


class TBLiteAdmissionPort(CispoHandshakeAdapter):
    """The admission port, plus the one readiness fact this container has.

    A TBLite attempt cannot start without the nested substrate and cannot be
    scored without it either, so health says whether that boundary is up. The
    *policy* is not checked here: under CISPO it comes from the executor's bound
    sampler origin, not from one of this image's own keys, which is exactly the
    difference between this surface and the platform's ``/health``.
    """

    def __init__(self, facts: RuntimeFacts, *, substrate: TrialSubstrate, **kwargs: Any) -> None:
        super().__init__(facts, **kwargs)
        self._substrate = substrate

    def cispo_health(self) -> dict[str, Any]:
        payload = super().cispo_health()
        ready, reason = self._substrate.ready()
        payload["substrate_ready"] = bool(ready)
        payload["substrate"] = {
            "kind": type(self._substrate).__name__,
            "nested": "host_docker",
            "reason": reason,
        }
        if not ready:
            payload["status"] = "unhealthy"
            payload["reason"] = reason
        return payload


@dataclass(slots=True)
class _RuntimeMetadata:
    """The fields the route layer reads off a runtime."""

    runtime_id: str
    capabilities: RuntimeCapabilitySurface


# --------------------------------------------------------------------------- #
# The target
# --------------------------------------------------------------------------- #


class TBLiteCispoTarget:
    """The TBLite Harbor world, installed behind both declared CISPO ports.

    The capability document is assembled once, from the declaration and the
    installed surface, and the handshake facts are derived from *that document*
    rather than reassembled -- so the hash the handshake echoes is byte for byte
    the hash the capabilities route serves.
    """

    def __init__(
        self,
        *,
        trials: Sequence[TrialPin] | None = None,
        declaration: CispoRuntimeDeclaration | None = None,
        surface: RuntimeCapabilitySurface | None = None,
        routes: Mapping[str, str] | None = None,
        substrate: TrialSubstrate | None = None,
        transport: SamplerTransport | None = None,
        reachability: SamplerReachability | None = None,
        clock: Callable[[], float] | None = None,
        handshake_clock: Callable[[], datetime] | None = None,
        handshake_ttl_seconds: float = HANDSHAKE_TTL_SECONDS,
        temperature: float = 1.0,
        max_steps: int = MAX_STEPS,
        max_tokens: int = MAX_TOKENS,
    ) -> None:
        self._trials = tuple(trials) if trials is not None else declared_trials()
        self._by_task = {trial.task_id: trial for trial in self._trials}
        self._declaration = declaration or tblite_cispo_declaration(trials=self._trials)
        self._surface = cispo_capability_surface(surface)
        self._routes = dict(routes or cispo_declared_routes(CISPO_ROUTE_PREFIX))
        self._document = build_cispo_capability_document(
            self._declaration, self._surface, routes=self._routes
        )
        self._facts = RuntimeFacts.from_capability_document(
            self._document,
            task_rows=tuple(trial.task_row() for trial in self._trials),
            handshake_ttl_seconds=float(handshake_ttl_seconds),
            container_version=f"{CONTAINER_ID}.{self._declaration.discovery.taskset_version}",
        )

        self._substrate = substrate if substrate is not None else HostDockerSubstrate()
        sampler = transport if transport is not None else SamplerCallbackTransport()
        probe = reachability
        if probe is None:
            probe = (
                sampler
                if isinstance(sampler, SamplerReachability)
                else SamplerOriginReachability()
            )
        self._sampler = sampler

        self._admission = TBLiteAdmissionPort(
            self._facts, substrate=self._substrate, clock=handshake_clock
        )
        self._admission.policies = CispoPolicyAdapter(self._facts, reachability=probe)

        self._attempts = TBLiteAttemptRuntime(
            transport=sampler,
            substrate=self._substrate,
            temperature=temperature,
            max_steps=max_steps,
            max_tokens=max_tokens,
        )
        self._lifecycle = CispoRolloutLifecycle(
            self._attempts,
            lease_ttl_seconds=self._declaration.lifecycle.lease.ttl_seconds,
            lease_renewable=self._declaration.lifecycle.lease.renewable,
            max_concurrency=self._declaration.lifecycle.advertised_concurrency,
            clock=clock or time.monotonic,
        )
        self._reward = CispoRewardAuthority(
            evaluation_plan_id=self._declaration.reward.evaluation_plan_id,
            reward_relation=self._declaration.topology.reward_relation,
            deferred_scoring=self._declaration.reward.deferred_scoring,
            settlement_window_seconds=self._declaration.reward.settlement_window_seconds,
        )
        self._verifiers: dict[str, dict[str, Any]] = {}
        self._verifier_lock = threading.RLock()
        self._rollouts = TBLiteRolloutPort(self)

    # -- the duck type register_cispo_routes reads ------------------------ #

    def cispo_declaration(self) -> CispoRuntimeDeclaration:
        return self._declaration

    def cispo_admission(self) -> TBLiteAdmissionPort:
        return self._admission

    def cispo_rollouts(self) -> TBLiteRolloutPort:
        return self._rollouts

    def metadata(self) -> _RuntimeMetadata:
        return _RuntimeMetadata(runtime_id=CONTAINER_ID, capabilities=self._surface)

    # -- what the ports are built from ------------------------------------ #

    @property
    def declaration(self) -> CispoRuntimeDeclaration:
        return self._declaration

    @property
    def admission(self) -> TBLiteAdmissionPort:
        return self._admission

    @property
    def rollouts(self) -> TBLiteRolloutPort:
        return self._rollouts

    @property
    def facts(self) -> RuntimeFacts:
        return self._facts

    @property
    def capability_document(self) -> dict[str, Any]:
        return dict(self._document)

    @property
    def capability_hash(self) -> str:
        return str(self._document["capability_hash"])

    @property
    def capability_surface(self) -> RuntimeCapabilitySurface:
        return self._surface

    @property
    def routes(self) -> dict[str, str]:
        return dict(self._routes)

    @property
    def lifecycle(self) -> CispoRolloutLifecycle:
        return self._lifecycle

    @property
    def attempts(self) -> TBLiteAttemptRuntime:
        return self._attempts

    @property
    def reward_authority(self) -> CispoRewardAuthority:
        return self._reward

    @property
    def substrate(self) -> TrialSubstrate:
        return self._substrate

    @property
    def sampler(self) -> SamplerTransport:
        return self._sampler

    @property
    def trials(self) -> tuple[TrialPin, ...]:
        return self._trials

    @property
    def policy_registry(self) -> Any:
        return self._admission.policies.registry

    def declared_horizon(self) -> dict[str, Any]:
        """The horizon, plus the post-horizon work that is still in the lease.

        The horizon is the agent episode. Quiescing the workspace and running the
        verifier happen after it and inside the attempt's lease, so they are
        budgeted here rather than folded into the horizon -- a horizon that
        included the verifier would let the reward describe an hour of grading as
        if the policy had spent it.
        """

        horizon = self._declaration.topology.horizon
        return {
            "horizon_kind": horizon.horizon_kind,
            "value": float(horizon.value),
            "seconds_per_unit": horizon.declared_seconds_per_unit(),
            "grace_seconds": float(horizon.grace_seconds),
            "quiescence_budget_seconds": QUIESCENCE_BUDGET_SECONDS,
            "artifact_budget_seconds": VERIFIER_TIMEOUT_SECONDS,
        }

    # -- admission -------------------------------------------------------- #

    def trial_for(self, task_id: str) -> TrialPin:
        trial = self._by_task.get(str(task_id or "").strip())
        if trial is None:
            raise TBLiteCispoError(
                f"task id {task_id!r} is not one this container bakes; the declared rows "
                f"are {sorted(self._by_task)}"
            )
        return trial

    def admit_attempt(self, request: Mapping[str, Any]) -> AttemptPlan:
        """Gate one submission against its handshake, its trial, and its binding.

        Each of the three is a refusal rather than a default: an attempt with no
        admitted agreement, on a trial the agreement never named, or on a binding
        whose sampler was never reachable, is refused before the lifecycle
        accepts it.
        """

        agreement = self._admission.admit_attempt(request)
        config_id = str(
            request.get("config_id") or request.get("policy_config_id") or ""
        ).strip()
        if not config_id:
            raise TBLiteCispoError(
                "a submission names no bound policy config; an unbound attempt has "
                "nothing to collect behavior logprobs from"
            )
        # Which binding this is decides which id namespace the attempt lives in,
        # so it is resolved before the id is minted rather than after. A probe
        # binding is never in the sampler registry -- every entry there is keyed
        # by a sampler origin and a probe has none -- so the adapter's own probe
        # registry is consulted first.
        probe_payload = self._admission.probe_bindings.get(config_id)
        prefix = PROBE_ROLLOUT_PREFIX if probe_payload is not None else "rollout_"

        rollout_id = str(request.get("rollout_id") or "").strip()
        if not rollout_id:
            # The container mints it. An executor binds the sampler origin
            # before it submits, so it has no rollout id to give yet; deriving
            # one from the idempotency key keeps a retry after a lost response
            # resolving to the same logical attempt.
            key = str(request.get("idempotency_key") or "").strip()
            if not key:
                raise TBLiteCispoError(
                    "a submission names neither a rollout_id nor an idempotency_key, "
                    "so a retry could not be told from a second attempt"
                )
            rollout_id = f"{prefix}{canonical_digest({'key': key}, length=20)}"
        elif (probe_payload is not None) != rollout_id.startswith(PROBE_ROLLOUT_PREFIX):
            # Probe attempts occupy their own id namespace so a probe id can
            # never collide with -- or be read as -- a real rollout id.
            raise TBLiteCispoError(
                f"attempt {rollout_id!r} is bound to "
                f"{'a probe' if probe_payload is not None else 'a paid policy'} but its "
                f"id is {'outside' if probe_payload is not None else 'inside'} the "
                f"{PROBE_ROLLOUT_PREFIX!r} namespace"
            )
        task_id = str(
            request.get("task_id") or (request.get("task") or {}).get("task_id") or ""
        ).strip()
        if not task_id:
            raise TBLiteCispoError(
                f"attempt {rollout_id!r} names no task; a submission that picks its own "
                "trial is not the one the agreement resolved"
            )
        digest = agreement.task_digest(task_id)
        trial = self.trial_for(task_id)
        if digest and digest != trial.content_digest:  # pragma: no cover - defensive
            raise TBLiteCispoError(
                f"attempt {rollout_id!r} resolved trial {task_id} at {digest} but this "
                f"container bakes {trial.content_digest}"
            )

        if probe_payload is not None:
            binding = ProbeAttemptBinding(config_id, probe_payload)
        else:
            binding = self.policy_registry.admit(rollout_id, config_id)

        correlation = dict(request.get("correlation") or {})
        return self._attempts.register(
            AttemptPlan(
                rollout_id=rollout_id,
                trial=trial,
                binding=binding,
                handshake_id=agreement.handshake_id,
                agreement_digest=agreement.agreement_digest,
                seed=int(correlation.get("seed") or 0),
                group_id=str(correlation.get("group_id") or ""),
                sample_index=int(correlation.get("sample_index") or 0),
                run_id=str(correlation.get("run_id") or agreement.run_id or ""),
            )
        )

    # -- the deferred verifier -------------------------------------------- #

    def dispatch_verifier(self, rollout_id: str) -> dict[str, Any]:
        """Start the second workload, once the horizon has been attested.

        Idempotent: finalize is called once, but a client that retried it must
        not get a second verifier grading a tree the first one is still reading.
        """

        result = self._attempts.result(rollout_id)
        plan = self._attempts.plan(rollout_id)
        with self._verifier_lock:
            existing = self._verifiers.get(rollout_id)
            if existing is None:
                handle = self._substrate.submit_verifier(
                    trial=plan.trial, workspace=result.workspace, rollout_id=rollout_id
                )
                existing = {
                    "handle": handle,
                    "dispatched_at_offset_seconds": self._lifecycle.offset(),
                    "outcome": None,
                }
                self._verifiers[rollout_id] = existing
                self._lifecycle.log(rollout_id).append(
                    "nested.verifier.dispatched",
                    {
                        "rollout_id": rollout_id,
                        "handle": handle,
                        "image": plan.trial.verifier_image,
                        "separate_verifier": True,
                        "workspace_content_digest": result.workspace_content_digest,
                        "at": existing["dispatched_at_offset_seconds"],
                    },
                )
        if self._reward.state(rollout_id) is not ScoringState.COMPLETED:
            # Capability-gated on purpose: a container that had not advertised
            # deferred scoring could not reach this line at all.
            self._reward.defer(rollout_id, reason="tblite_verifier_not_yet_reported")
        return {
            "scoring_state": self._reward.state(rollout_id).value,
            "deferred_reason": self._reward.slot(rollout_id).deferred_reason,
            "verifier_handle": existing["handle"],
            "verifier_image": plan.trial.verifier_image,
            "artifact_budget_seconds": VERIFIER_TIMEOUT_SECONDS,
        }

    def verifier_outcome(self, rollout_id: str) -> VerifierOutcome | None:
        """Poll the second workload. ``None`` means the measure is not readable."""

        with self._verifier_lock:
            state = self._verifiers.get(rollout_id)
            if state is None:
                raise TBLiteCispoError(
                    f"attempt {rollout_id!r} has dispatched no verifier; scoring before "
                    "the horizon attestation is what post-horizon reward drift looks like"
                )
            if state["outcome"] is not None:
                return state["outcome"]
            handle = str(state["handle"])
        outcome = self._substrate.poll_verifier(handle)
        if outcome is None:
            return None
        result = self._attempts.result(rollout_id)
        outcome = replace(
            outcome,
            workspace_content_digest=result.workspace_content_digest,
            started_at_offset_seconds=float(state["dispatched_at_offset_seconds"]),
            finished_at_offset_seconds=self._lifecycle.offset(),
        )
        with self._verifier_lock:
            self._verifiers[rollout_id]["outcome"] = outcome
        self._lifecycle.log(rollout_id).append(
            "nested.verified",
            {
                "rollout_id": rollout_id,
                "container": outcome.container,
                "image": outcome.image,
                "exit_code": outcome.exit_code,
                "separate_verifier": True,
                "isolation_mechanism": outcome.isolation_mechanism,
                "workspace_content_digest": outcome.workspace_content_digest,
                "reward_outside_agent_workspace": True,
            },
        )
        return outcome

    def verifier_status(self, rollout_id: str) -> dict[str, Any]:
        with self._verifier_lock:
            state = self._verifiers.get(rollout_id)
        if state is None:
            return {"dispatched": False}
        outcome = state["outcome"]
        return {
            "dispatched": True,
            "handle": state["handle"],
            "dispatched_at_offset_seconds": state["dispatched_at_offset_seconds"],
            "reported": outcome is not None,
            "exit_code": None if outcome is None else outcome.exit_code,
        }

    def settled_receipt(self, rollout_id: str) -> dict[str, Any] | None:
        try:
            slot = self._reward.slot(rollout_id)
        except Exception:  # noqa: BLE001 - no slot yet is not an error
            return None
        return None if slot.receipt is None else slot.receipt.to_dict()

    def deferred_reward_payload(self, rollout_id: str) -> dict[str, Any]:
        """The answer while the measure is not readable. Not zero, not absent.

        ``reward`` is ``null`` and ``scoring_state`` says why. A caller that
        reads this as a zero has mistaken "not yet" for "nothing", which is the
        one confusion the deferred capability exists to prevent.
        """

        slot = self._reward.slot(rollout_id)
        return {
            "rollout_id": rollout_id,
            "scoring_state": slot.state.value,
            "evaluation_plan_id": slot.evaluation_plan_id,
            "deferred_reason": slot.deferred_reason,
            "deferred_scoring": True,
            "reward": None,
            "verifier": self.verifier_status(rollout_id),
        }

    def reward_metadata(
        self, plan: AttemptPlan, result: EpisodeResult, outcome: VerifierOutcome
    ) -> dict[str, Any]:
        """What the receipt has to be able to name, beside the number itself."""

        return {
            "task_id": plan.trial.task_id,
            "task_content_digest": plan.trial.content_digest,
            "split": plan.trial.split,
            "metric": "tblite_verifier_reward_txt",
            "authored_by": "container_verifier",
            "verifier_image": plan.trial.verifier_image,
            "verifier_container": outcome.container,
            "verifier_exit_code": outcome.exit_code,
            "verifier_isolation_mechanism": outcome.isolation_mechanism,
            "verifier_dispatched_at_offset_seconds": outcome.started_at_offset_seconds,
            "verifier_reported_at_offset_seconds": outcome.finished_at_offset_seconds,
            "agent_image": plan.trial.agent_image,
            "workspace_content_digest": result.workspace_content_digest,
            "patch_digest": result.patch_digest,
            "steps": result.steps,
            "commands": result.commands,
            "compactions": len(result.compactions),
            "declared_finish": result.finished,
            "policy_revision": int(plan.binding.policy_revision),
            "behavior_identity": plan.binding.behavior_identity,
            # The reward record says whether it scored a synthetic episode at
            # zero provider spend. It is one of the structural probe marks, so
            # it is stamped by the reward authority rather than left to a reader
            # to infer from the rollout id.
            "probe": bool(getattr(plan.binding, "probe", False)),
            "deferred_scoring": True,
        }

    # -- artifacts -------------------------------------------------------- #

    def artifacts(self, rollout_id: str) -> list[dict[str, Any]]:
        """The attempt's inventory: the workspace, the patch, and the trace.

        The workspace is the one artifact this container declares by reference:
        it is a directory, it is what the verifier graded, and inlining it into
        the job store would push a whole extracted repository through a route
        meant to carry a receipt. The patch and the trace are inline, each named
        with its own content digest.
        """

        result = self._attempts.result(rollout_id)
        payload = result.evidence.document.to_dict()
        return [
            {
                "artifact_id": f"{rollout_id}:workspace",
                "role": "workspace",
                "media_type": "application/vnd.synth.workspace-tree",
                "content_digest": result.workspace_content_digest,
                "inline": False,
                "reference": result.workspace.workspace_id,
                "route": self._routes.get("artifacts_route", ""),
                "retention": "run",
            },
            {
                "artifact_id": f"{rollout_id}:patch",
                "role": "patch",
                "media_type": "text/x-diff",
                "content_digest": result.patch_digest,
                "size_bytes": len(result.patch.encode("utf-8")),
                "inline": True,
                "content": result.patch,
            },
            {
                "artifact_id": f"{rollout_id}:trace",
                "role": "trace",
                "media_type": "application/json",
                "content_digest": result.evidence.trace_digest,
                "size_bytes": len(json.dumps(payload, sort_keys=True, separators=(",", ":"))),
                "inline": True,
                "route": self._routes.get("trace_route", ""),
            },
        ]

    # -- release ---------------------------------------------------------- #

    def release(self, rollout_id: str) -> None:
        """Give the workspace back. Retention is ``run``; the tree is not."""

        try:
            result = self._attempts.result(rollout_id)
        except TBLiteCispoError:
            return
        result.workspace.release()


# --------------------------------------------------------------------------- #
# Installation
# --------------------------------------------------------------------------- #


class _UndeclaredRuntime:
    """No declaration, no ports: the route layer answers 501 on all seventeen."""

    __slots__ = ()

    def cispo_declaration(self) -> None:
        return None

    def cispo_admission(self) -> None:
        return None

    def cispo_rollouts(self) -> None:
        return None


def install_cispo_target(app: Any, **kwargs: Any) -> TBLiteCispoTarget | None:
    """Mount the seventeen declared routes and install the target behind them.

    ``SYNTH_TBLITE_CISPO`` decides what an undeclarable deployment does:

    ``auto`` (default)
        Build the target if the renderer profile can be declared and at least one
        trial is baked; otherwise mount the routes anyway, say once on stderr
        what is missing, and let every route answer the contract's typed 501.
        Route presence and behavior support are separate questions.
    ``required``
        Refuse to start rather than serve a surface with nothing behind it.
    ``off``
        Mount nothing. The image serves exactly what it served before.
    """

    mode = (os.environ.get(INSTALL_MODE_ENV) or "auto").strip().lower()
    if mode == "off":
        return None
    routes = cispo_declared_routes(CISPO_ROUTE_PREFIX)
    target: TBLiteCispoTarget | None = None
    try:
        target = TBLiteCispoTarget(routes=routes, **kwargs)
    except TBLiteCispoUndeclarable as exc:
        if mode == "required":
            raise
        print(f"[harbor-tblite] cispo target not installed: {exc}", flush=True)
    register_cispo_routes(app, target or _UndeclaredRuntime(), prefix=CISPO_ROUTE_PREFIX)
    state = getattr(app, "state", None)
    if state is not None:
        state.cispo_target = target
    return target


#: The key this image advertises the seventeen-route table under. Unlike
#: ``banking77``, nothing on this image has already claimed ``cispo``.
CISPO_CONTRACT_METADATA_KEY = "cispo"


def cispo_optimizer_block() -> dict[str, str]:
    """The advertisement block: all seventeen declared routes, under the prefix."""

    return cispo_optimizer_contract(CISPO_ROUTE_PREFIX)


def metadata_extra(payload: dict[str, Any]) -> dict[str, Any]:
    """Advertise the CISPO route table beside whatever the platform declares.

    Advertised whenever the routes are mounted, because an executor has to be
    able to see the shape it would talk to; whether the container can honor a
    particular run is the capability document's and the handshake's answer, not
    this block's. Two keys are added and nothing existing is renamed, moved, or
    overwritten.
    """

    if (os.environ.get(INSTALL_MODE_ENV) or "auto").strip().lower() == "off":
        return payload
    contracts = dict(payload.get("optimizer_contracts") or {})
    contracts[CISPO_CONTRACT_METADATA_KEY] = cispo_optimizer_block()
    payload["optimizer_contracts"] = contracts
    # Which build actually answers these routes. A receipt has to be able to name
    # it, and on a workstation the stream comes from a checkout rather than from
    # the pinned wheel.
    payload["cispo_import_path"] = CISPO_IMPORT_PATH
    return payload


__all__ = [
    "ADVERTISED_CONCURRENCY",
    "AGENT_INSTANCE_ID",
    "AGENT_TIMEOUT_SECONDS",
    "CISPO_CONTRACT_METADATA_KEY",
    "CISPO_IMPORT_PATH",
    "CISPO_SRC_ENV",
    "COMPACTION_KEEP_MESSAGES",
    "COMPACTION_RULE",
    "COMPACTION_THRESHOLD_TOKENS",
    "CONTAINER_ID",
    "EVALUATION_PLAN_ID",
    "HELDOUT_SPLIT",
    "HELDOUT_TASKS_ENV",
    "MAX_STEPS",
    "MAX_TOKENS",
    "SECONDS_PER_STEP",
    "SETTLEMENT_WINDOW_SECONDS",
    "TARGET_SCHEMA_VERSION",
    "TASKSET_ID",
    "TEAM_ID",
    "TOPOLOGY_ID",
    "TRAIN_SPLIT",
    "VERIFIER_TIMEOUT_SECONDS",
    "AgentWorkspace",
    "AttemptPlan",
    "CispoSourceMissing",
    "CommandOutcome",
    "CompactionEvent",
    "EpisodeResult",
    "HostDockerSubstrate",
    "HostDockerWorkspace",
    "SamplerCallbackTransport",
    "SamplerOriginReachability",
    "TBLiteAdmissionPort",
    "TBLiteAttemptRuntime",
    "TBLiteCispoError",
    "TBLiteCispoTarget",
    "TBLiteCispoUndeclarable",
    "TBLiteRolloutPort",
    "TrialPin",
    "TrialSubstrate",
    "VerifierOutcome",
    "cispo_capability_surface",
    "cispo_optimizer_block",
    "cispo_source",
    "container_image_digest",
    "declared_splits",
    "declared_trials",
    "heldout_slugs",
    "install_cispo_import_path",
    "install_cispo_target",
    "metadata_extra",
    "prompt_program_digest",
    "read_sample",
    "renderer_profile",
    "taskset_version",
    "tblite_cispo_declaration",
    "workspace_tree_digest",
    "world_capability_surface",
]
