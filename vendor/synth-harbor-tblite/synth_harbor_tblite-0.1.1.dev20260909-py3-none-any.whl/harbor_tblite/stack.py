"""OpenThoughts-TBLite image PID 1. No sidecar: the Harbor fold IS the image."""

from __future__ import annotations

import os
from typing import Any

from synth_containers.image_main import image_main

from .targets import HARBOR_TBLITE

IMAGE_ID = "harbor-tblite"
DEFAULT_TARGET = "harbor_tblite"

TARGETS = {HARBOR_TBLITE.target_id: HARBOR_TBLITE}


def extend_app(app: Any, **cispo_kwargs: Any) -> Any:
    """Everything this image declares beside the shared platform's surface.

    The platform surface -- ``/info``, ``/rollouts``, ``/policy-configs`` and the
    rest of the compat table -- is built by ``create_compat_app`` and is not
    touched here. The CISPO contract is mounted after it under its own ``/cispo``
    prefix, so the canonical paths the two tables share keep their existing,
    blocking, GEPA-era semantics.

    ``cispo_kwargs`` is how a test installs the target with an injected trial
    substrate, sampler transport and clock, so what it drives is this wiring
    rather than a second copy of it.
    """

    # `SYNTH_TBLITE_CISPO=off` means this image serves exactly what it served
    # before, down to not importing the contract.
    if (os.environ.get("SYNTH_TBLITE_CISPO") or "auto").strip().lower() == "off":
        return app
    try:
        # Imported here rather than at module scope: the CISPO stream is not in
        # the wheel this repo pins, so a checkout without it is a supported
        # build. It then mounts no `/cispo` route and advertises no route table,
        # which is the honest answer -- and every other surface is untouched.
        from .cispo import install_cispo_target
    except ImportError:
        return app

    install_cispo_target(app, **cispo_kwargs)
    return app


def main(argv: list[str] | None = None) -> int:
    return image_main(
        image_id=IMAGE_ID,
        targets=TARGETS,
        default_target=DEFAULT_TARGET,
        argv=argv,
        description="OpenThoughts-TBLite Harbor platform",
        # Beside the Harbor task the platform already serves, the CISPO contract
        # the same task can be trained under.
        extend_app=extend_app,
    )


if __name__ == "__main__":
    raise SystemExit(main())
