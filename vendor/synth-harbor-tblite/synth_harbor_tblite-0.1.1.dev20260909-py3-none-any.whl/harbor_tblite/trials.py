"""Locally baked, digest-pinned OpenThoughts-TBLite trial images."""

from __future__ import annotations

import os
import tomllib
from functools import lru_cache
from pathlib import Path
from typing import Any

from synth_containers.nested_runtime import TrialImage

ENVIRONMENT_REF = "env:harbor_tblite"
CORPUS_ROOT = Path(os.environ.get("TBLITE_SRC", "/var/lib/tblite"))


@lru_cache(maxsize=1)
def pins() -> dict[str, dict[str, Any]]:
    path = Path(__file__).with_name("pins.toml")
    if not path.is_file():
        return {}
    with path.open("rb") as handle:
        payload = tomllib.load(handle)
    return {str(key): dict(value) for key, value in payload.items() if isinstance(value, dict)}


def task_ids() -> tuple[str, ...]:
    return tuple(f"tblite/{slug}" for slug in sorted(pins()))


def trial_images() -> dict[str, TrialImage]:
    images: dict[str, TrialImage] = {}
    for slug, pin in pins().items():
        root = CORPUS_ROOT / slug
        instruction = root / "instruction.md"
        if not instruction.is_file():
            continue
        workspace = str(pin.get("workspace") or "/app")
        images[f"tblite/{slug}"] = TrialImage(
            id=f"tblite/{slug}",
            image=str(pin["agent"]),
            workspace_source=workspace,
            workspace_mount=workspace,
            extract_command=("bash", "-lc", f"tar -C {workspace} -cf - ."),
            verify_image=str(pin["verifier"]),
            verify_command=("bash", "-lc", "/tests/test.sh"),
            verify_mounts_workspace=True,
            logs_mount="/logs",
            reward_path="verifier/reward.txt",
            result_path="verifier/reward.txt",
            reward_on_nonzero_exit=True,
            verify_timeout_seconds=float(pin.get("verifier_timeout_seconds") or 3600),
            verifier_network=None,
            agent_timeout_seconds=float(pin.get("agent_timeout_seconds") or 3600),
            instruction_text=instruction.read_text(encoding="utf-8", errors="replace")[:30000],
            environment={"TBLITE_TASK": slug},
        )
    return images
