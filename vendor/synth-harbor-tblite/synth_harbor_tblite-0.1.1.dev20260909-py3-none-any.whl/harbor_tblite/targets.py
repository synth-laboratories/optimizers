"""OpenThoughts-TBLite target with a Tinker Qwen 4B mini-SWE policy."""

from __future__ import annotations

from typing import Any

from synth_containers.nested import nested_health
from synth_containers.nested_runtime import NestedTrialRuntime
from synth_containers.platform.affordances import AffordanceMap
from synth_containers.platform.targets import PolicySeed, RewardKind, TargetRuntimeKind, TargetSpec

from .trials import ENVIRONMENT_REF, task_ids, trial_images

TINKER_OAI = "https://tinker.thinkingmachines.dev/services/tinker-prod/oai/api/v1"


def health() -> dict[str, Any]:
    return {**nested_health(), "corpus": "openthoughts-tblite", "runnable_tasks": len(task_ids())}


def metadata_extra(payload: dict[str, Any]) -> dict[str, Any]:
    """Every optimizer contract this image declares, in one place.

    The shared platform advertises what it advertises; the seventeen-route
    ``synth_optimizers.cispo.v1`` table is added beside it, under the canonical
    ``cispo`` key -- free on this image, because nothing here ships a predecessor
    rollout contract under that name. It is added only when that module is
    importable, because it is only mounted then, and an advertisement for routes
    this build did not mount is worse than no block.

    Imported lazily for the same reason ``stack.extend_app`` imports it lazily: a
    checkout whose ``synth_containers`` does not carry the CISPO stream is a
    supported build, and on that build ``/info`` answers byte-for-byte what it
    answered before.
    """

    try:
        from .cispo import metadata_extra as cispo_metadata_extra
    except ImportError:
        return payload
    return cispo_metadata_extra(payload)


def admit(_platform: object, request: object) -> dict[str, Any] | None:
    task_id = str(getattr(request, "task_instance_id", "") or "")
    if task_id not in task_ids():
        return {
            "error": "harbor_task_instance_required",
            "status_code": 422,
            "advertised_task_instance_ids": list(task_ids()),
        }
    return None


POLICIES = (
    PolicySeed(
        "qwen35_4b_tinker_mini_swe_compact",
        "mini_swe",
        {
            "model": "Qwen/Qwen3.5-4B",
            "base_url": TINKER_OAI,
            "api_key_env": "TINKER_API_KEY",
            "inference_transport": "tinker_sampler",
            "max_steps": 50,
            "max_tokens": 4096,
            "command_timeout_seconds": 300,
            "timeout_seconds": 3600,
            "output_limit": 6000,
            "workspace_aliases": ["/app", "/workdir"],
            "compaction_threshold_tokens": 48000,
            "compaction_keep_messages": 10,
        },
    ),
    PolicySeed(
        "gpt_oss_20b_tinker_mini_swe_compact",
        "mini_swe",
        {
            "model": "openai/gpt-oss-20b",
            "base_url": TINKER_OAI,
            "api_key_env": "TINKER_API_KEY",
            "inference_transport": "tinker_sampler",
            "max_steps": 50,
            "max_tokens": 4096,
            "command_timeout_seconds": 300,
            "timeout_seconds": 3600,
            "output_limit": 6000,
            "workspace_aliases": ["/app", "/workdir"],
            "compaction_threshold_tokens": 28000,
            "compaction_keep_messages": 10,
        },
    ),
    PolicySeed(
        "nemotron_35_lightning_tinker_mini_swe_compact",
        "mini_swe",
        {
            "model": "nvidia/NVIDIA-Nemotron-3.5-Lightning-30B-A3B-BF16",
            "base_url": TINKER_OAI,
            "api_key_env": "TINKER_API_KEY",
            "inference_transport": "tinker_sampler",
            "max_steps": 50,
            "max_tokens": 4096,
            "command_timeout_seconds": 300,
            "timeout_seconds": 3600,
            "output_limit": 6000,
            "workspace_aliases": ["/app", "/workdir"],
            "compaction_threshold_tokens": 48000,
            "compaction_keep_messages": 10,
        },
    ),
)

HARBOR_TBLITE = TargetSpec(
    target_id="harbor_tblite",
    runtime_family=TargetRuntimeKind.HARBOR,
    adapter_chain=("harbor",),
    world_ref="world:openthoughts_tblite",
    environment_ref=ENVIRONMENT_REF,
    evaluation_plan_ref="eval:tblite.reward_txt",
    default_policy_harness="mini_swe",
    # The DooD runtime extracts over `none` and puts short-lived verifiers on
    # Docker's one shared default bridge. Unlike upstream Harbor's per-trial
    # Compose topology, it does not allocate a bridge per rollout, so a
    # 30-member optimizer group can run as one wave on OrbStack.
    scale_leases=30,
    retention="run",
    reward_kind=RewardKind.SCRIPT,
    live_reward=False,
    live_frames="unsupported",
    true_checkpoint="unsupported",
    blocking_trial="native",
    mcp_bind="unused",
    reconnect="derived",
    event_kinds=(
        "trace.opened",
        "env.episode.opened",
        "nested.workspace.extracted",
        "span.policy.opened",
        "span.policy.data",
        "span.policy.closed",
        "nested.verified",
        "reward_signal",
        "terminal",
        "env.episode.closed",
        "status",
        "capture.closed",
    ),
    policy_seeds=POLICIES,
    max_episode_steps=1,
    runtime=NestedTrialRuntime(environment_ref=ENVIRONMENT_REF, trial_images=trial_images()),
    health_probe=health,
    admission=admit,
    metadata_extra=metadata_extra,
    affordances=AffordanceMap(by_role={"environment": {"poll": "native", "sse": "derived", "blocking_trial": "native", "nested_rollout_environment": "native", "scale_leases": "native", "bind_policy_config": "native", "token_trace": "native"}, "policy": {}, "evaluator": {}}),
)

TARGETS = {HARBOR_TBLITE.target_id: HARBOR_TBLITE}
